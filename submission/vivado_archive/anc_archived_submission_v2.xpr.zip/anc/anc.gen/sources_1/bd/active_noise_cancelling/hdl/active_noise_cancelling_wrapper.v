//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.1 (win64) Build 5076996 Wed May 22 18:37:14 MDT 2024
//Date        : Fri Nov 20 10:43:37 2026
//Host        : DESKTOP-DE44A2S running 64-bit major release  (build 9200)
//Command     : generate_target active_noise_cancelling_wrapper.bd
//Design      : active_noise_cancelling_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module active_noise_cancelling_wrapper
   (pmod_amp_din,
    pmod_bclk,
    pmod_err_dout,
    pmod_lrcl,
    pmod_ref_dout);
  output pmod_amp_din;
  output pmod_bclk;
  input pmod_err_dout;
  output pmod_lrcl;
  input pmod_ref_dout;

  wire pmod_amp_din;
  wire pmod_bclk;
  wire pmod_err_dout;
  wire pmod_lrcl;
  wire pmod_ref_dout;

  active_noise_cancelling active_noise_cancelling_i
       (.pmod_amp_din(pmod_amp_din),
        .pmod_bclk(pmod_bclk),
        .pmod_err_dout(pmod_err_dout),
        .pmod_lrcl(pmod_lrcl),
        .pmod_ref_dout(pmod_ref_dout));
endmodule
