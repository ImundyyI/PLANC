// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.1 (lin64) Build 5076996 Wed May 22 18:36:09 MDT 2024
// Date        : Thu Nov 19 21:52:22 2026
// Host        : aiden-pc-kubuntu running 64-bit Ubuntu 26.04.1 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/aiden/COMP3601/Assignment/submission/hw/build/vivado/anc.gen/sources_1/ip/mult_gen_0/mult_gen_0_sim_netlist.v
// Design      : mult_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xck26-sfvc784-2LV-c
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "mult_gen_0,mult_gen_v12_0_21,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "mult_gen_v12_0_21,Vivado 2024.1" *) 
(* NotValidForBitStream *)
module mult_gen_0
   (CLK,
    A,
    B,
    P);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF p_intf:b_intf:a_intf, ASSOCIATED_RESET sclr, ASSOCIATED_CLKEN ce, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [17:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [17:0]B;
  (* x_interface_info = "xilinx.com:signal:data:1.0 p_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME p_intf, LAYERED_METADATA undef" *) output [35:0]P;

  wire [17:0]A;
  wire [17:0]B;
  wire CLK;
  wire [35:0]P;
  wire [47:0]NLW_U0_PCASC_UNCONNECTED;
  wire [47:0]NLW_U0_PCASC_EXT_UNCONNECTED;
  wire [1:0]NLW_U0_ZERO_DETECT_UNCONNECTED;

  (* C_A_TYPE = "0" *) 
  (* C_A_WIDTH = "18" *) 
  (* C_B_TYPE = "0" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "18" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "3" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "1" *) 
  (* C_OPTIMIZE_GOAL = "1" *) 
  (* C_OUT_HIGH = "35" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "zynquplus" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  mult_gen_0_mult_gen_v12_0_21 U0
       (.A(A),
        .B(B),
        .CE(1'b1),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_U0_PCASC_UNCONNECTED[47:0]),
        .PCASC_EXT(NLW_U0_PCASC_EXT_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_U0_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
GldLassLiODVgwPWl5GtUvNFVA+ZFVCFDhi7OrBop0rEIGOD7pGMQGd2XL5uXmDjnBa10M9DWskh
bTmllY5ovkWmM+NjjKYtf65BTGkYfwgKQ0A0l0q2oaCRiZEI98rgXRzWg4blHjn3F8mvlotras3b
gty58LDcqChRb34tHz4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YcKo5o/69htYDEreuDNtMbaQmtugz53TAiA3xMek1XTrggXZnceDK+Oacp9AwNeiNftWOxMl66sc
GrZixCPC4jC03qefsJitE5tQCfx9LEom/ln0gke2S5U676zqGFFkGD4igDSppP9+7smsit0JMNFB
3d9nJDwNXaerv07edmo26kGx6IsxHNmGjsmUd8FYgoMDNNDiTN40UA7rfTR1c5FwRoOUAPNW8x7l
lmsL+1mbpRU3rvmnc+tPlMZ9USQRFaWSLPznAatOpRgaHOa1J4DFd6nwIAGf3cDLilhq3YGA2oUb
qXHyz/+dnLIidWUJj1UPrzhk+3OEiFNdeXBKsA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
g4qhHdak8eXxEqdympBtDM13xMJwZUSekBKApv5XlolRI2rR14IEYNQEcKRGlZyuFCmDRJDrEYWf
Eokybg18xq2N2hsq8nA4pvk6H9PXJmnhKoFcPeZ1j9mOnXNuEaOZnL6sA21bsPP7tTakNFG0eaXB
2vlDGYPDupMpXlylpEQ=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YIONylalBSo3oXqXlsOxHxbPAKbTQFLUkNcqhxYuBHSYbie+16iUZHVqekHM1nIPQ8A+NqZHT/Cn
bM+AOf7At893GAAiJmLAoJJQdHh7oO33naeJX4XJ6I+8adw4O4AucHf+iXdDTh+vT4ToH3pNI1H/
fg7BSszZg69zgY/QsPHraQkyFn3n6Pi12TK4KdE5CdqP1IapEJzDzFftP3QIdgztNEm32O7R9UAV
Qu6VW5iu2mw976oaaPRS7xQkeSuh8v3dIBFLuXEUwqgjFtQ1YItY1vsqSSX+qAtcmYqxSAn3rSTu
J315oxld+eYjvTtO32Qn2VPHVzfXPLCqIWAfbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ggUMon3tDyL18D99zI+gQo2KEmq86nD/UnuCl2KfpNz4G8UqOi9eijpYl6B8kVrp4KbnZWqTmMMF
z/O87hlmFpp4opDcOruJ+qiiTBWsOzFIQR4QZlanEjh8iO0cwSFSAz5sXdE77BCjzgHI7D4UD4Mp
5DA2KyFTsWztU8ricXXTuH6tZLNTLcTvHzJkt/DfkjmJrDlkm0eRAXhG0MUvkNsk32qCBY9RY9AF
1rJxG2dj5ZCJ2l/vueboa3iQZt2OeB1EloxrJDFuQtvPAvA65BsTM387sUTttprjm7eb5Tm0FQU5
vVHNxCllfsk9jW0rLIKm7dBRCgOntC9jDiJa0g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
q5sQqbKwLxjG5mFk9qs+sD0CQg8/2B7KTHpwf62hzJF+1CFbVJUQ6go3DO5L0L1mUNINJPIKzaAD
66tkeRifjCdb0XYOSTAxArc1zlCtOMwOn0aTyha/Uq8sc44kv2JFuUoIsn/Tl15lAT4q5PGV1fNq
fyS1evlpX2NGjZCT9kx21/uYFVn1ltB09OkXy1tz0sskN2eMyg54gf1l6cTR+xsVdY2hIoYfIVN9
H8DudSxoFGmVq3nTkLEuIBwpOzIdlqxG/+zUbvpOhAOprRojoI7OuuNVnv8kqbudzrZrZDK0HX1J
I5lc8/JLEOTV1hKGDSaSt1UBFUvr7e8cCqERRg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dpec57YobDtonbQ0UO1SM8G+H4LNYxSkwZ+IOdocIPgFV2eNfdKVGLe5M3kGiFH8cY+OBkva9enL
/OWjF9TA2LAxTndxgG5J0pfUvCDOVC48MZgZnIR8dOHrP7D6LGWfbebBGB9V1IoBt63/ke8Gi6uZ
oukujbRqqhLpZtf77LbVOpOjZYXM0v1IplnrAPnLmHL9Auh/wBXbYFGVV+VhmRndax/hdT5NuXTd
OGVqvHjKXMT4qzPWpaROPHYFYtTWznHqjj27TLk/z5Hdp0nlp4+Ebp4zIwYMnSpg5MVSetpPiSCZ
031Hd1PlF/YfYwbU1r9lJTGrVWMqi/+gd8KaCQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HlE05c2aGsR6rjiuATQqbaTq27Z8ZtyCoeTKodnH2OaArT49PLi5ZL6waWhdrvL68et08IAUs9t+
8aQnVdhvb/0fNHwtevhkpK8kJCPhJmdNdN0DS60RUdlb5/sgSQWjlxx4Yz5wWXrD3w3dhNQaJbzb
PdLh3ZWUZ+ldIzf3OmxXqghMZwvXkPIkeVkEZK5rBVF4df5DItd6+GOemFxXJmppL3ChWMcSlJD6
hgFBtCxft+usPb88sDNxtsPNBhH8Yeq+nZ3gc7A2wXdVKQugUXMV+/6MH4QJagSTzkjs2wVuXfk8
YQcZf8t0t2eS3XkCFdUszXwMtQ8YgrBWqnZp6aSas1JlXWWMk1d316/ym9sdD+dt36sxmIOjr/mr
lNnHAn9fdTEGDWsaXok7ujwI96+Jo6VVX3h+8Qo/6f9dvmB+j9wX01yLiteRc/klH0QWWPFrckTr
rxvZC+0DnkSyRPCISuHF9Op/7iDXfrGDXOIKpGzdPMaHMsKqIpG+QnAb

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fff66ZCQIGGWn4BfihDr7MvimxiiOWXc0eZBNa52g6soH+VWc7Xx3RJ4fuq721E6hCeRxrTK72LX
i9jipHmkI+YxSSUZyntNbeuF7P38Z8QWyEXrCSRJqnLKUeNwU2D2v692GIbbkPNs3o1/p6bS+PZV
fy4p7pkkxRTdZGKmGNuXlDtPr5DhZ0zFptZiF4rQKB5ebp50U6h6HWEJapeIaJRVwy77CM+u0fDT
4A/3o3rPHumuUTiliaQcm/1jofwW8Wyt/fEyoDeskyKFiJxA7nvXRFcO7dw8hnBN2by3mEq8uvFc
fsXjl6FQ6E8njLb3YPebcEhF2fiQl6tfqv3Xsw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TPuKSC49PXr1CyJdt/9jlK1AKgl9KP/2WJFt/Z7vtljlmD6IwyvQTKF40mFUq27M5Fuz/W4X5INe
/y1uccitx3VcJsarTiaoGT9S3DEmWfAhW9Z3EJmLNoB5WF+Gt3VSrbcIFx4bRg1NbAvCsu35cwJ8
qIEuedLHAD9VsRvFu3kQcKMgbKlMKJWQKJUShZN0gC0lrTnoVAzLqEKMNA0qhQg6q9MlU0GGAeTU
4OAGi9IXN69mtGYQcFgRHTN2cuQvbBPQfXj7zjLG/WzUgoqFUvAhtN5JMPKijnF83gwj845lsPtD
BdmC4FzXoM7Od2ck/qbMAIXHv6TTsjznVFUQBg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dz0VP1CnlNHH+A6VEdv/MzTzitzJy9mXlBCOCHhiN+w9HtFx0dUiXe3p32oSt/JL5Z+78HPWFZNr
norYJdshbBxv2VA+Qb4W2FkhsUt+nbeUxZGkOXoHhhGec2Yij8F+xw2PzGlLK+EcjoVFUGoblbgy
lZxtUK/qPijjN/wQqhHPSvrKrho4ht3zcjZjVg8ZVfzx3x04m5pTyiTrTQecuIFEiVC5ZAhCQMxN
lUXGjCmiY2z772Cy8Zi5NhUXuo2561aTzEHBTJmriI9CVs50fIl0kofkrrA0OdX5CS5GkPv09EPz
ZPD7/ZAVOXqA3AlDcqAsaheUQnXkFpEPunVR0w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5728)
`pragma protect data_block
dBfOwqcKudSeCvU6PeAxReU+5b/MusoQd5Ai023D5EGpY5joLK1Pp8phNJDGjR7YFKgLwFMJLg+o
YytWZAU6TP5SL+H6/frg8V0JmmMUr9vmqE7Y06sfHul9uHhJbGQtjQ2A/kTXHKjgtRZTtH8VAnsB
W03yD44AHMfSS6Q/OlQkzZ/Afd/P+n5z89496ZbmWsN/fEA/5FWKRqnveZPAs78yCWoQwQoEmXuB
W/YH/vkvRro5mkWWacLS8bydL8wo5TTRdc9RoiWUqh1ZQpfDHgd23dQ4wP9X1d+MQk5z8CgMaV1/
ZFVVZw1jh9sG2mAewJg1AE3tgGJMwCWrIJjKCfjx2zMdcfOF5HeU16te5ghZwYvaqXRhw6D8ZBYy
0RSsNl6Ma0j9lcTM4LTScLPvEAVaUW2nY+HUeV7zMUuzghQvvcowRcmpa/UnmiZihUSQD5QWoS7s
hSDWDjQjFBemkCgLtjITn2bemA0UrFFlfFd9OHtD0jHPEgpjpTzatbiF1acnNde8YwDoJSz80HLW
jTdRC22f85FYqcri4conmcDvNNKeBMHJaypJcf416jNUOUJVmFAYq2oTbqNN6EvCjiL1ertdJ5fB
ahTtY7Ef8zt6PX0G1JrVdlryrG0AvLF+xcwkbTghxRQmhLQcVGx3MB0gvAD6XVxenssn4gGWZo8J
54dj8f4FPThDP0D6BEaAnSEamOu1qun0+7lWe1oZ7PuWbX4m17fu3MssvNmZ9yIM5Uj2D6ajDudA
hk4+Pi7U8BthhspyVmGnwoA7lvWnE79cxXj8WJ7141T5OfYMvJWLIXluhIp2BNw5E1omAhlLtxZC
Up+lICWnniDtAG9TMUzZJzr+X9N37y6jI4F/kKkSX9pl4woHs0Kx7+fDqhpP+tRoDW9Av//3uBlF
BkZ6A4S/Le0abVADIOnn5AphiPnK7kkTSDuUoEtWWqbMfCYD0579EPrhMAp7TKB+i6WGVKBpwiLU
XB/M5VdJJbGR9dlQSMlbSU2kIFYQe0gdE7MSa0vUkm2nUr4oHoNUP+A/FMbU9tWryD3mbrFvmvxm
3I+Br1EH5C352VO09oZe4bL12sBEHo4Ycw2ojHrKMlzVpT9EZw7SiuvhENoukA9XfOvGzmIB0c8X
QktWEhVz57tBsO6PeiSRV4Q/BgO9mWEsSrKMFOqS9hEuDzl3LpX0gy27vrLyYGU5UVj5m0BeL5ft
o20vJkrX2OqDsDV2ntNb1fyQ2E+Oh8zXX857d4Cy/qGo8786iBFKI3wxsQ2bDkUt7lGd3+RLSWT1
T7dmObHpQG15FcItyBFzcBoMXqPENBau6kRVEIQMMh2rh2G0obHn/bdNj9JKvO/Go6P3NNeu5b6a
sJihznBLcRQVUaVBCzXwLD6bIdi/5+mo29ZbSJZ5K45JR4vYlkHhuKN8cMxs949uZPLoMt+oGCIy
KQtGrSBj8M1TiMQ+pNdH/kANtrFf6FnQimK558pMTgTfFTjPvsdwq0lJGOVK2XcQPaiUlARSamCU
h6IbxvP/KCJkEDije34lMuCR5rRnN3vr7yg2eAMdhn9pl4KOhs+ac90lWxuZjuqmwygbpOtJsKae
1Xq2jbSWtxP88E4q0SQakF9SMpA95ugQNNNkank6SsCCY1IF/9AGxR0s896+EyVUpwIfIOv1ClVS
G9DA0AoIvpcF2Lj/1qt3D7X06iqAg3NttQs74dfwxiJ5ELvBzY0heVauThBSG1bEkvMdG1tXYZ7y
/An91h4FYskgDOgUjkGBNGTOs0MSqkFdX4KlzLhH/l5P2fvv+340WCt3a4DTae79cyBJJUUz6UFP
5sZ/4VWYMTPAe8gRcYbpkGc6nIz9GMVoUSu16VSuZwH9s8NRyscp9E5pKmnLUMRAx3bUidWpjV0L
Gr/GaJ+1Wh6EMSw9d4R6PTmUPmeXm+ijAY5L/6dEhYvEFikEyuB+GJpeFGqNZyDGwlWmqcltqYWB
paIoICRvil1wD7OrD07NUvWKN67QiBfxs21IpsYJBCXoAA2FzcjVeeR/sTaqH9zlK6HnhyiBWx+j
1I2zGDEftLOgrxSlRUQnAFPUW8tVkGxUp8O35xSzqk2CQdoR5AEJvTVimWupZTmIcxqFVRjyOFx/
yjmrfhpStACzV/o1qiT+i/LfLjyxYa25nCtR8Vdxkp/f45mQKQ5Yzvl3oU4dDHmK6CmBQgQmTv75
FPjg2Vbf2i2i54HJ8W3KXyB5pzd7RLncxoM0qyxiJ6Zst1La0CpEFxb+fUqn0lUqtgWd1neh70ux
ijKo33fel54CUPHRc8Tqb+oLWJkdGBmXScA6e6C2HJmPx8KSRizihvk3mkKVSRJsjCDqjxXu6dk6
RPnUXXy5f+XHV4PxM/cAoXQsu+dK6R1yg4dkdUDUyCTP9qqinaagUtN1EB+vAfPsDXCuQz2P59jF
zj97fITk8W278wi8FUamFHZgjMI2G/YuXUmIj0/3FjZxfPxPrZfZGdeDlE06wwxyXdfj3r7Lx07m
BDYWG/wLZ/VSq6wR3l7grzjZnEY+UMc4tu3IqcH9Vp1GUpxxtq9QJw6dR/fFwopEBCfrlma/qNCH
rYRiXUe0dta9g1ircrMJRNlVL5C66iE/q87CFKC4fTNMjmnCvy5UoL60RR2Ta0WqyBVu8yl3XYgV
/tWm+EYu1X6wT0L9PkQ0aJ+EZjiteEdzV+DNql8toiAogyINP8qdupNaWYTenDcE8sq6oYXbfEwZ
xOeNPqWDHxb/Yi6W8oX13tqdMvI2V/g2dCzvT/5jxovQlbnOCb5bTXFWWKbq3np5dSgo06iE2jta
XWqff/NoALvBy8H82rXz3wauMmUToVfb4489UjeyaX2MkZ4MXmcXIKpQ15sqvORyPLoyVqa9P6yL
zDHHk4vmJOhQEiylVVlUx4NYPbgG1ogZW7RsJY57398PjemzLRCn2Zhd2pU+zmFemEcfrLNohW6S
BPDHQtYIxGzBoEZRNuzggzjMOq/nhAeOLcV05pN3OxcLEBcNbSz9O9/iaINnnglBMwNQsTMb6eZh
EIpCOeBj5t9t8RteFcXN0t7JBpaZsCo/+6uS9H9jEP36jQWe6C3OG3AYRpI+SozXw0jREhwhruBC
cnhsNjlNLvyz786kriEX+apTosCeMwhVoXETRQJVS4ynPmAQx55jDotN4PBuw0MZXuLkKfunCwzb
CyUhF65PULGwasfq24Qm5mwdScOwKaq/eB2SjKr+PDiBZv/nl9fdo9rOZWlPfhlrwJgy7b2K7bGw
Jnv+fpCe7KjCLhC19pFczwch4uSSVNfqepOS7PyMHXYJ6yErbwhX2BgRFIaG6IRWl6N2sITg0A4G
BpcnQIs4RXd9Kh1Ng7zNwCRMG/fZF4kPUOgv609RmUzBNdLa7b5ODfpgaL1aYYmbjqPqCVLtHBfG
zlyzlleAiWyY+96Cg1peTUhq6BLOn7e5EpfDA5CzYCKoTzbJfGYJQIcqoGQdJES3JlmQljrt3vTH
poecwkd6Fg3y5cS97RODrguoMVA+VC/hYEtFIUmizr1xTKNEfPgNi39wsWiAtJtY4DbzK2xjE/ne
2QDLBiyQeyIV4+c+yOuvGH3M8nW/+FeEOv0dcU9LiE25+/Ss1c7zUrsWB2nHFDOQOEAvyozHJr5O
whsLJrrNlgcXz5Gu220urqQhCnrMNWjkeKOOnwVCDYR4ZlpcH+ec2LxFCwswu0+G+UTnAwt1IFdr
Iz9HsL4tmqUBN+roXR277U36ijoSotblpXiIMBwjoJkNRe14i0nxxQmVUJ9EdXsoIoF5DDLftpU1
0qjmdZ15a9oOavuugy2g6VehpXlXJbJC1wjfCBfub+wBNwtKT5oaLWDezuIO/0SXQffrh0IP/7v9
CaOIYPwng9D2K8jKJUBXjkGA+36SzkdTLYcqNd1rBbSGQwcfExq9eTQslAwmzTfqnVmU0YbnVLjy
H0bDVwSxPjVEW6ZbKjMjpGN5U1P1ueHklacrwmMQu/j7K7A6ShdzUA4yk8JLljmbG5pmelG9JUvu
e6+nFgDz3Ci2DOQ+B4stQ5NNqG0WIbdO3O8dFF1lWHm8TPY4cReohRJPlF+E5l98VyLct1YMu2/t
Nq+2+0apTSBVHyXCqjUCGMroHc5GGova0P+cFjkwrh9ttCxUNOsug5l0dzLsDnF2HCoQYQD+Q5MY
j3m37Jbw+Yf5tOJdSOoqaU/QXamDVPFqQOepgtNm28kw/3WHHt1hE+omdQ9Mz7VayQifAmPuu5yN
U20+R5JcDYfgGMJ2T5H3tX8JGrH2bhufgeIcYnBQIXCi2aPEG7s8i12uXnMxlu+0OvtkUVvSBNx4
JklhD2t1zl/6HrMwtcOYxIOYTefqCZIExaPCOrOOLIXdkBHMrYt6ygQujcmLVZV60YkS/DI1aR0P
jq+Guk6xTW+q72y0GP/xOTBP3OK6fdpCPvmcPYH7CckELFUx9d3LM9JEMFGK7Gs64pUSV/S7RS3v
3IwQCClST3xcPs85vORCHHtBYpmS2zaDkIHifcbmIDDhk3CYqVZSfNIYZ3dXe+ZEIbhkpW0UVBAT
ml8/JAjRZcxacev8i6RW6ppBAD5qrUg31xXwjUeiYYMaJQNDu6gFre103wmPlWlSIB+rYl0CE2Fi
AhJWx8L52XfUwQq2G6OY2SxTh8B6oghPxHxg6KssweniYr9/bNZJcRJsD/xg+5XGFnVQSQQy8lrM
toFq7+4ynEVnpKJS5ws9HAKO6RNFfMsdUMHOWL/EV8yGaRKk+4f43HSEGe9MF1pnsqT5FLVd4YJM
KRv3JPwwCndXSC46tW7jjzG4lKqOuCcxvXQNFJEjVAIRad4DgFmQZleBLnVWqUWZJXQ72S9mz3QO
NcRU7wsREkD/nNA699XSg4aQguSQiTy9D/VzbX1AllClQNWflvB1rHxTtIcXAtaRsCwja/6CN6zP
64KFxxu1WYaJ4wGtaWPc9u8FQZl/AOA4lIYiO3RftEc3ElmNMWwQS66IR0+UReTbsoeItsQChQ+R
ve3It2ZNCx/X4Fhydoba+eVo4uug+/cWhmINMPCoIprkJWY8c46i7C8R/Fbdmr0bLA3tWg3+tIrG
+mz00vwhT3Rn2A+iMnNZTAJC2ZRMWWCQ8T3Jv8mmbIuQQz6w3QLKKVN5Gap1YdT+KBzkiQMem4aU
pgDWsEiN9y6Fn/8AOUubKK1yedazN0p9Y7OKbDa3ZGvHJXa5zTlX319pszHeFpClOIE3x6TAo6C4
hvI/pQYKs/nEz5D0XJZbZlcvLHUZb1OV5DEqxjZjtLu8Y89qwMdhtYly0fW8Q1Z1FDYEaePgVWwI
MQalq1FcrMIsBD0at5YMm1JjNQn9T1hcsSPaZzD4smVI5GqcW0srKfB6B7c3iXBpoFdMkndfqQZC
qiIweAZpJqPcmSGvtWPYcszYE0KIv5tmE0i0dPk1K6b9zapfZsypxAdHV4X/K6hqzHrM7boWC9mU
LTpvMSKHhyrUcFPNwTshy0JKG4+V+bXtcZYE1Fkggy6B/MTi6bKUrEHKGOaAyIfsxzUPoHginnTK
KuOLvgqBNTzo4F+ARujNb1vaR+eP1e2w7jiLXKlo9upH3rfsXNZgT23baOx/y3Wgy8hqxtmMD9L6
68jBRszkothMlhvRczOD6wm7H77UFbfTUDVoxy1Q9EFO0/Q1f0D1LfkrX16I4De8gvy1ImY3t1In
6zW7u2ec1TxuFREqa857r630rmmUo91byQo+TG7gWdKznOTWYBQ/Q4NLgp5kSqCuUxoRQAy1Ek/2
undx331O9N4o0wMqrPAXSp2j7ecaRRqLzqYQut2XfzqXxyqL3KKuPi7SHlpDOWeH4dxSc3XqftOB
mxKktQ/4I16MesMAkwv/7hH3c0ENg+QAaLa94U6Hmpffv3Bw6GubYjMvisQbYZ3NVzq/sWdSIU8V
on+h6NK1CBjs2RVMydthH/avXy6s1qQmap8DcxFvQXvWgWL2ZMVbBClhzPQ9z4HafVg9TNvaC1dq
NWup4w14rq1+yY7LShrAZOS/RuK7EVmJvZHMyb6VVLegK7dPFSJPAnxsKv/Y/2rPV0ptH4P9HXFR
tVGIrzRCip74IqdokE5xIEVfucF6ctokWxNluoBD6zy2YjoFe+CWkfAmdUpESJlb6aW3ohgM57JG
xDXky1yEnGpPG2PzA/5ZItXmNmPJ3Iexs5xFUVD36gAsk9eDgtY07zIqdHm/3/phOufji6s6iEZB
5K2Gxiuymy7UGxu0h2hRjyWGILRZ83VdHOAQLA2YPzlMSXtl/xTwT9CaN0VD5chHW5NLa5yRXeBW
xio9fTfgzyV4LGN+K0I1UMinTdHSQJVlTHKvqzNSH64lFbDvID63flajOkiqka656yvjhO/LeJIU
+V8H4I3s0dKbTIa6kY0oFTxcckMSQg+loSSA4pb4ah43DcK0aYIVPAW3OtL+70Dc8K9AO2hGD3xI
ksxDZGEelyWFpZ07OFobIsoh0J1EzIqENHr8zXM0rI5SkMlYJfQGQiW8J1RSgmTJndyFLxxB5hI4
lFjlViJtvdJEKDPy1XUTaCUlpZybhpKJPcmMjrmQpaB/vis1p9xe+YQlx+Zbjg9DYriEND2KzOEi
dJTmQpfxgVrVUUFoNEGAv+nxOft96oxQZ1c8rmdN1/jgTYXxC2J2hsh+RGWky7kIlSk5R6uGuz+O
YFQrSluZeu0kzgfVBJxgiFZbToSzOMu2VH9XLy58UqHZmOB4OWjnZRzpcNFxYmjFfCaYajJgfQ2n
PTkku56c16NZyYhq1VauTgvrNnldUuUGyICfRooVj+xfGQZ4+MutvKIVyEUe8lWeKdHihrFC0RJY
1RGmLksdhnMKxgNvoA2vr4V4WElZv+e3V+wS3Gz0ij9UVUl2MD15Q1qVkkvb3BUSRGyduniV5mrj
nBv+3dbRy7eRHTf8brNXvPSptPQqxQ4LvYzMjNVGZ8XgXA6QBtxSgW3Bm2YwdcA6x5ShJF+7OZYx
N86vYinJRoqDfi1sFPbIvEH/JIgw82MeO+m1clSadDkWEamASfiu/1cEnaXFqvR/ZGfKo2Wz2dAv
krkOQL6A4FgIQYGqMlok861ftHRxV+GZ9yfv2YTaJdgoff/pvWPVqjOoyd8V8qt0cxtAoNruIocs
Qjz2kBGAr0XNfbDT2BuFnLdwmNKaJb0R5n0Q9fTwB8Hq4T/Wka8Tg9VIoQ/9yRozLaVNAEJkj64o
lq3dap/QQQxi3qhv4ovJe1H1DqPZJGUpZO71gRIP9c3JdKFh1zN7toYrQCk3kQ4pcjrbieZ4hX9N
jU0sy2r6ksjqoY3WgfYU0wvseZhVtoA1OOKyPj3sZPx1WMtC1BqlyyqaqGX9wf0PR0Duhb2QNc+4
9IaQ6bcbCkYPiSHRusRmxaF6UMBhysdWccmKCm+mkSr2rcIAfZj0TR/L9aehYCsp9zSoYbzk/ABJ
5PgeVp/x8k8/A1QPBmGNvisxJ0vZv6k+zI9KrVYoUYZi4sR9ObkNNPtt1gNB8Kxkx6TCHBecgKYh
5DHOtHpfa4nei2OTIjnqIQC4t0XUnEqxGUNcr5W092hGQ4GOU0t6yA7NMOkxlS2fzgsDB4EcYm4W
5v7j059VLRSwSDhrAOeebFonfSzaigyuj5AzbA==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
GldLassLiODVgwPWl5GtUvNFVA+ZFVCFDhi7OrBop0rEIGOD7pGMQGd2XL5uXmDjnBa10M9DWskh
bTmllY5ovkWmM+NjjKYtf65BTGkYfwgKQ0A0l0q2oaCRiZEI98rgXRzWg4blHjn3F8mvlotras3b
gty58LDcqChRb34tHz4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YcKo5o/69htYDEreuDNtMbaQmtugz53TAiA3xMek1XTrggXZnceDK+Oacp9AwNeiNftWOxMl66sc
GrZixCPC4jC03qefsJitE5tQCfx9LEom/ln0gke2S5U676zqGFFkGD4igDSppP9+7smsit0JMNFB
3d9nJDwNXaerv07edmo26kGx6IsxHNmGjsmUd8FYgoMDNNDiTN40UA7rfTR1c5FwRoOUAPNW8x7l
lmsL+1mbpRU3rvmnc+tPlMZ9USQRFaWSLPznAatOpRgaHOa1J4DFd6nwIAGf3cDLilhq3YGA2oUb
qXHyz/+dnLIidWUJj1UPrzhk+3OEiFNdeXBKsA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
g4qhHdak8eXxEqdympBtDM13xMJwZUSekBKApv5XlolRI2rR14IEYNQEcKRGlZyuFCmDRJDrEYWf
Eokybg18xq2N2hsq8nA4pvk6H9PXJmnhKoFcPeZ1j9mOnXNuEaOZnL6sA21bsPP7tTakNFG0eaXB
2vlDGYPDupMpXlylpEQ=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YIONylalBSo3oXqXlsOxHxbPAKbTQFLUkNcqhxYuBHSYbie+16iUZHVqekHM1nIPQ8A+NqZHT/Cn
bM+AOf7At893GAAiJmLAoJJQdHh7oO33naeJX4XJ6I+8adw4O4AucHf+iXdDTh+vT4ToH3pNI1H/
fg7BSszZg69zgY/QsPHraQkyFn3n6Pi12TK4KdE5CdqP1IapEJzDzFftP3QIdgztNEm32O7R9UAV
Qu6VW5iu2mw976oaaPRS7xQkeSuh8v3dIBFLuXEUwqgjFtQ1YItY1vsqSSX+qAtcmYqxSAn3rSTu
J315oxld+eYjvTtO32Qn2VPHVzfXPLCqIWAfbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ggUMon3tDyL18D99zI+gQo2KEmq86nD/UnuCl2KfpNz4G8UqOi9eijpYl6B8kVrp4KbnZWqTmMMF
z/O87hlmFpp4opDcOruJ+qiiTBWsOzFIQR4QZlanEjh8iO0cwSFSAz5sXdE77BCjzgHI7D4UD4Mp
5DA2KyFTsWztU8ricXXTuH6tZLNTLcTvHzJkt/DfkjmJrDlkm0eRAXhG0MUvkNsk32qCBY9RY9AF
1rJxG2dj5ZCJ2l/vueboa3iQZt2OeB1EloxrJDFuQtvPAvA65BsTM387sUTttprjm7eb5Tm0FQU5
vVHNxCllfsk9jW0rLIKm7dBRCgOntC9jDiJa0g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
q5sQqbKwLxjG5mFk9qs+sD0CQg8/2B7KTHpwf62hzJF+1CFbVJUQ6go3DO5L0L1mUNINJPIKzaAD
66tkeRifjCdb0XYOSTAxArc1zlCtOMwOn0aTyha/Uq8sc44kv2JFuUoIsn/Tl15lAT4q5PGV1fNq
fyS1evlpX2NGjZCT9kx21/uYFVn1ltB09OkXy1tz0sskN2eMyg54gf1l6cTR+xsVdY2hIoYfIVN9
H8DudSxoFGmVq3nTkLEuIBwpOzIdlqxG/+zUbvpOhAOprRojoI7OuuNVnv8kqbudzrZrZDK0HX1J
I5lc8/JLEOTV1hKGDSaSt1UBFUvr7e8cCqERRg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dpec57YobDtonbQ0UO1SM8G+H4LNYxSkwZ+IOdocIPgFV2eNfdKVGLe5M3kGiFH8cY+OBkva9enL
/OWjF9TA2LAxTndxgG5J0pfUvCDOVC48MZgZnIR8dOHrP7D6LGWfbebBGB9V1IoBt63/ke8Gi6uZ
oukujbRqqhLpZtf77LbVOpOjZYXM0v1IplnrAPnLmHL9Auh/wBXbYFGVV+VhmRndax/hdT5NuXTd
OGVqvHjKXMT4qzPWpaROPHYFYtTWznHqjj27TLk/z5Hdp0nlp4+Ebp4zIwYMnSpg5MVSetpPiSCZ
031Hd1PlF/YfYwbU1r9lJTGrVWMqi/+gd8KaCQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HlE05c2aGsR6rjiuATQqbaTq27Z8ZtyCoeTKodnH2OaArT49PLi5ZL6waWhdrvL68et08IAUs9t+
8aQnVdhvb/0fNHwtevhkpK8kJCPhJmdNdN0DS60RUdlb5/sgSQWjlxx4Yz5wWXrD3w3dhNQaJbzb
PdLh3ZWUZ+ldIzf3OmxXqghMZwvXkPIkeVkEZK5rBVF4df5DItd6+GOemFxXJmppL3ChWMcSlJD6
hgFBtCxft+usPb88sDNxtsPNBhH8Yeq+nZ3gc7A2wXdVKQugUXMV+/6MH4QJagSTzkjs2wVuXfk8
YQcZf8t0t2eS3XkCFdUszXwMtQ8YgrBWqnZp6aSas1JlXWWMk1d316/ym9sdD+dt36sxmIOjr/mr
lNnHAn9fdTEGDWsaXok7ujwI96+Jo6VVX3h+8Qo/6f9dvmB+j9wX01yLiteRc/klH0QWWPFrckTr
rxvZC+0DnkSyRPCISuHF9Op/7iDXfrGDXOIKpGzdPMaHMsKqIpG+QnAb

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fff66ZCQIGGWn4BfihDr7MvimxiiOWXc0eZBNa52g6soH+VWc7Xx3RJ4fuq721E6hCeRxrTK72LX
i9jipHmkI+YxSSUZyntNbeuF7P38Z8QWyEXrCSRJqnLKUeNwU2D2v692GIbbkPNs3o1/p6bS+PZV
fy4p7pkkxRTdZGKmGNuXlDtPr5DhZ0zFptZiF4rQKB5ebp50U6h6HWEJapeIaJRVwy77CM+u0fDT
4A/3o3rPHumuUTiliaQcm/1jofwW8Wyt/fEyoDeskyKFiJxA7nvXRFcO7dw8hnBN2by3mEq8uvFc
fsXjl6FQ6E8njLb3YPebcEhF2fiQl6tfqv3Xsw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TPuKSC49PXr1CyJdt/9jlK1AKgl9KP/2WJFt/Z7vtljlmD6IwyvQTKF40mFUq27M5Fuz/W4X5INe
/y1uccitx3VcJsarTiaoGT9S3DEmWfAhW9Z3EJmLNoB5WF+Gt3VSrbcIFx4bRg1NbAvCsu35cwJ8
qIEuedLHAD9VsRvFu3kQcKMgbKlMKJWQKJUShZN0gC0lrTnoVAzLqEKMNA0qhQg6q9MlU0GGAeTU
4OAGi9IXN69mtGYQcFgRHTN2cuQvbBPQfXj7zjLG/WzUgoqFUvAhtN5JMPKijnF83gwj845lsPtD
BdmC4FzXoM7Od2ck/qbMAIXHv6TTsjznVFUQBg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dz0VP1CnlNHH+A6VEdv/MzTzitzJy9mXlBCOCHhiN+w9HtFx0dUiXe3p32oSt/JL5Z+78HPWFZNr
norYJdshbBxv2VA+Qb4W2FkhsUt+nbeUxZGkOXoHhhGec2Yij8F+xw2PzGlLK+EcjoVFUGoblbgy
lZxtUK/qPijjN/wQqhHPSvrKrho4ht3zcjZjVg8ZVfzx3x04m5pTyiTrTQecuIFEiVC5ZAhCQMxN
lUXGjCmiY2z772Cy8Zi5NhUXuo2561aTzEHBTJmriI9CVs50fIl0kofkrrA0OdX5CS5GkPv09EPz
ZPD7/ZAVOXqA3AlDcqAsaheUQnXkFpEPunVR0w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 9408)
`pragma protect data_block
dBfOwqcKudSeCvU6PeAxRelCxyVlnBcKRUN85giqeH0gqaJ1CFVovf/7AO58ZOWAts3kddKkdji1
PmSw6QVqlETt9y1R50UQY5r38kLF6c+KZ2dHBd+GGACaiyggcHr7HudJ4Cp9un9h8xtLpny5CaY9
0EJjqIdfIWPLPiQH5dmfuJ+ZqrAjaQqC+bUvbxM4xTQznZhdRYuZtS+5vaESSmvcW1JaPIbMWPTG
j0GJorXAlnc7o3MM9lDYnrHfZlKKH8imR0q+hEG2CIaPZi2taOLJg5X5QhQfykX8Sp3sI6PPHA88
lG8QYVWuy7HWIhJmAq89kAjLsIl50AyfAMOoL8fpGZXXkGLqfdSdqvqUdG+SzO4hMnYoepXrcbly
shoQlTDT65aEHXiJUuVHgMD0lBAW1KAILLWR1fXEhA5qpeBmxckUvFR+cCbYVT3tfFMG3gsNdg2l
obuLaSUdYlC4CYqSLpvB1ySVT80+Ry25LccDWPd9I807dx/w2amXOtlYYqLw98nAomvXqn+FHzDp
Munczgg7kzxRUWKdmpYyFNkddCPrxwcgEdu3Y25f1KfBgOuCcDkxcebvTiJHwOiYAQy0oLQGDFRF
mpXbT/GNOv2pIcqtKlTPc7NnCusyMVa+d7cyibwlTAMK5ZW7mmgT8J3hUi6GDYU7u3DRxaC8UuK3
M3t5Q3+KLdpJZmJKgGiPZ5Lh+KaTnkCJ7QvJk3CCowkrikRMrwXlAWQW0kxx7ikHWkQQOTV30nwr
Qu86mMnSYEmGCQJHij7Bg+Ct9artKwwy6BmByiLQ7QzfEc1PO6pFiHrjGgPleJ/U+cseGAWNUDJT
2DUN18bcZCu+dm+8EPrSbgeuq8Syl9vDSUbdACTOvgZyWl369SjvbjvtomT60SG77EWPeNLPZANN
A5qxWZNFEjF77yG+3TkfP2HNs9rDyP7F9VVq/abzhHnTcRyOMc2kMxP+T37nGNp4WBJGtsiiKj05
PFHmpPUbB+voYf0z3sLrsWgmMdcNoRHmUGYkifoZN6L0gbCdQmeYkfl44TE4YodG8pqnUatkJEZm
Wqbsz+5pqgHL7/E6dYODypAuSPU3GQ8IFL+08hyYgUzS+v0TrdlJvHgQsTJ3+cPwzhhizB7TUWBW
G1iWsqnQhAa9PGbTOSbAGBwzSJTERhnSHjvpxmynHaeUXzdOYmMYST00fiD9MayGGyJJYGQAHgnO
DK1k7wxjBWOBHVwupYToUcMzsAEEf1Ei9Ou8kzmyjc0dFauPI+tMS0RjKGYnJG9pHmndw63P7XoT
LrBvEo+gqO0UEIiKeGcs4CHJJ3im2f85cEFpN9qjDzPdRvrBo+IsTVr6S9bma3H3bhdb6J3WZNlf
V8EBxnQxRuD88+QWlHiPXP6u8956XRHFANPX6UCx/xBFYvWWmW6epKrb3SlWrDSIxivwktZ4JOoX
7VRAGf2a4+684XHrPhMVhdGrXOwxi3qgOCW8tEcZuc2YtycQsxycQaC8Nyl2+jmBWtwC3QlXpZ0e
AA62mZcSAtN9J5FEHZ/yTYGW6gI42d3ZnS9pCU63jTIxln7sqOENCgaEi8buHBHL1HM5z3wso7U6
aouC5yLZRJlE59JcXRLWbqoAF2nFd4Dssnpm80+phP1QOVPdSZZveEmujpAeX+DOEeHwMiVauZx6
LOAPHfilQiHtCFHDy4KRdvyIHM5veZofY7wbyKunKIt6Q91Nv6ja3vTvNHCgaIyCEtuKq3gQZSNI
zbjPwBv480NiJJl8CYjk/eFTrIiHZCnsEGPnVSHMn154YwDpOaWbkWwHwLRQICKVA3OagIsbkSCw
TbWCvDoRpkp/QNIXW+WmHhAhNI3VkuArAQR695orKloh/PoEmB41OB0PcXCVWTTCznwW8NEtTV34
SyWqZ/0WL93kQYemDEuO7OLMZzljuxrHVx7wKdiZFHbKhHmWdbPMIJVznMe0cHbKYiaTnQ5Hine3
a4GYlwOZJPwLS4M6W3JJaD9lxDXWVxYATKv4WwdwmpCdeJ2cd6TuveioUJ7e2wyplgAUetb6el1Q
RHHlaIQyWYZ6CTcwB1beM8jvbpd5MtDC4pyFtO7Coj+48T6i6vVQEOxoF8vOb5H5WryfNCZv0n2H
s1IccJLjFTDByJYV6DJ5gGbbz03s+15x6RDleL94PgYZRkYLpYYRIVi2xL34vtzd4N8uMnsj+8LE
MyL2E7T3zply72/rOh5wewbGMUEyot0b6sZo2CKXXSeH8U+MG6tsL0NuSGeG7COA7xvM1nmT1LR+
JO1R2NfNjqBLehGW37Xt+7qCNN+ZfQGGiVWcM3q33UWuyi0/g6gBJwhnxzz/+8QKdGDXo0/VACCC
qcuGuxhcx9G7bjI98pGY5xxqfdR7sRfTNpN5R3Ena3UE+X7GciA2k/wGlJ0Wn3YHJdsn8xEvn7ZD
gofiPGbI0O3Vzbr976Sz4rszy1uEVSh9m7/vFKoGGeICWgmVD2lt5myOxxcPboY1rq9FaTQXLnwh
4dFdo5rcHiPDTJ9f/Y3LAgOA/VHeFvOqYTuL+/djbci3iXIZyzpXIvTTRJ2dKuGH0fyD0TNK0KF4
9tJd/MUZKWHL0LYFi0PMGev+Gm/oF+P93kdofLpV4JCihuRviARXvB6RhS1Uw40BDs4b84h0zZd2
bVPauQLDgS1AmWCPTwycFcbZfGzGik6M0ur3xfhoxeXqHLtUX/FSmyD4vDFBNpV36pK6cM0gAS5z
Au6bo0QL8x4vtkon9cYPNUxhcTFznfBa0dro7SWbOsveBhyPy+U7656NiA+D9KAXAg9CrERATpeq
XVtHvcS0y1KWtUHUJSSJNjLAO6xvupolQcOV/PTF7hWstdGYmTTSaAP6zXJtW6JdX0lXee2L/GNe
nMh2WE9UQszEc/H7K/VWhkJNaxrQTFPAXoaaXc6sXZQAsTS7daLQRtz66E/18QAcjtEHUpLfX/S3
j405JVLCdVbGDzWXqh3fCRYr4XkSyrPwc+X7Vb+ZL+FMN9j0ReU0PixeFgrD99Xn+hBKnWt6jpmx
+PqhlV/wiIZrz6qCvlwC0EuHQhXc9EmF/m0+a7II9QS06XUQrz0Oo0mZHH2x8J1vpXQWEw5q2W6a
15/+BxZX3A59lxpWxilreHTJIeQTl8U9HXZ+Y1mtaknZTg2CViyfv16I9iVwRPuXwWFX6UIveyWs
amVVG/onP4veLlXVGn1QzyJvFHCxp29QNEXmGCc6ikDjy6CA8YyZX5Q89EviJ1bGJbA3LhdsFD4X
zQF8egUGw2xM93mv5qL0z1oeRyO90N/7uKAB81XL/CiCeNlDT3rTlk2azUr5NMI1y8GX2lW3r2Dq
LDF3J+4JocGQqE/ruPbTa23/FEl8Y+kSwnRhFBgYsP3LPBrbDJQSLBVb1qlw4BkbXW8blfm5Hr57
682BwTXJRkqaxtz+qpz0Ui7PYap9LQP/awVRofsdEiPD6UOkQ35btM7VFldK3y1p5G9h0lQ/bFBi
t8zzpxFYvRDbNhaRNEaI3BhxAv3vqpfu//abjYw45278UsUvohUFSCem9+h3IKmvuMgbNihpHwAT
7fTgzkuu9f9a71H+FZ+xU3DPAoUI+sliGcfdTaFxjxt6gkUDxLARpAPBEyJYuo4xzkqpXy+dZeHk
VR3Bl4Z6EjpAvDd4SK391NsNJgml1cs3CZpBJBggNazGTsm9TT1WjsQto+imaTLC439E/HU7W8vP
GkMesuoyn8Se6kc3vd465l/xSQi+anlXuNynDeq4HoVlT4FoUY1Ai40I6H86v+HDHCMEHYHSyT3Z
jWa+zWN3DFHJlqTjd5HMEOc6QJjEVr7QtH2wy1pzVgLptOPCMi9CNIzx7SZoEffV/0KqI0xZwIuY
/bhyj0nU1zPnrwbnrtkj1dXMNMFPMAbHhw6cxbQkaDE3FPA5setOk+Aly0VHBTCRX2yHGzyeLmd5
6PnhNpK+4nT1PAyWwkxShsrzTIpYjPzHvUmAFGWy+mYw9Mkbv0Y3u8N1L5h3D34R/91quExv9Y15
w2BnnOfX3ohSQ7rQS3rIHjqkkXnhpkjH7MN1oKnW3zLUg1molsJZnhO0Z+dP7KreG0lGL1s/li/0
szWafr3gFwjpp8fvuU1QXdS6/jtcSIufDvOc5SxKrywryisSqbm+eR6z7V56TuJaHQgUQ/dv+C08
Bbh0k18zPpAUBbjLmQBDCieQJRE+8Gwe6ohB6DEr1W/0oWvfeGeIYZVBPxv1J6gqyx4C7dBY5AYW
2y7EAIT7+yLNzA8781cuI/XhFmqgC2GHuTuRRU4fGNc0paXBKPf1o9IZHvLq53lW6AIvGhSKptvw
luPr/opZLmf9a7K4CdRPS2FviwwYlUeq1X/+3vHsFiwRu1OF8dHCAvIQdrLB8fnVyRhjoREuZDmt
qM6EfMmzB5m1r+b1GBmAu39fatEQsntKraaSDR/8hmhdiyhKSwON/lLRQzH37htH0Il8DLuiPsW8
EhlmpACPg6FPAqm3QGm0bbpVl+5d81R8CuAr3U7VQsMfnjpGF0H2ZW4C0SYePBy/tcniVs4+TBx1
OtONZVYwj7vZMJSYilx7VWwpFO96I8xLofjfliQKhik2LBrhrwe6HW0iZM3LH5HcJ7BL8FZIbdAh
/il2K3mTQRQNhOitU2qAhOkdWKbKrl5kYnfQVSDPLPzWb0Nv807l2HvnoSRK6VGcs7r+8EIOwcRu
lQVsBgSKJn98i8qQMtgew10JIfbOnraVsBlfTiMgY9LdQxryfxB3lggkxvFRAFXZv0X0nivJEcVK
fJNvktNOd/Shosu6CHeF/BIQt5WMkAO9VnHE4Pg6VcM1ESUqZONAf7ivrd21GFBE8nTP9IWlJwSp
7LPlFDfQ5+K3VU8cI19Ib8FCLP5M43wy/8ex9JcM0AL9Qo7sqOwt5vslZXmj1ysvxDFw9mYTX9Z4
o3rw6FUedGeU6lAGwYOo4Kxduk6ODmv1svK8utyACFW69bu8s1gZWtkHIs4vuFQjTaatKOSInJm6
L3g3pgN52eXB5xsRZ5uA35BthV59q5wJY/Cf7LS2kq/cOVjhCt/idDMLAz/nMIfU5ZDhpw39xtQH
dpG5b+bR/ZxBMRQqPcLhScQndHi61nRyWgNxnU5G8jFMOj9QA2eZiMbPJyjO3IUxBZK/Yj2Z1F16
49IQYnVWfBDFjDI4wqFU6sDZAWfbqy4/Vvu3QRNa+jMk0ppv7avgrpOp6c+ev3MvMfgZRm5e6FDR
r95vsU7QgpqU5kCI6r8vkNTjhXiA5e5/O0PZhX5xkpd6P6vL+nvDJmv4qNVoIT/RD6Sfjq8TKkLn
e9VDdghHxVU8I+L6crLhzVfr9czNVoqRTlC7S1n9OEKPOzxD0U8p7nHP6mA6d5AkJL590xXoQ0ZJ
+hJjfLsZi8aoa+NkS7C0zVZyPsqODx73YzbO1YpDiJOutQuyD8TsbR3vffm9JUiTQjBYHrvhf8QJ
tv2/oz1r/yRMs8mMGn1IA4tLbp1rjGPuALclhFRwF+vXBVq4yKJDO7n1iEhWbdLzZ/NU/pH+DMgg
0dJSYTKwA6udOHXgwXLzmePdqkJ/uOqJHDGiWUo/x+CRnlLyXHS1BBwSc8gDGLhkHoWuo+MRIiXw
5RYoVZYcLlDGXfoPu134C85rqyvfO4e6f4BKK2IbalAt7Kd8HbGvqu1ASURSfs/5P13o4iK4cyc1
rMv9wIgT6nlaUORnBUQ5jIvdP0X6xhQpe66o0PD2DYP+Z7eg6XtUUuzVHXSb7Msgi4oa5c1rMQQG
F4v8zWOp1D/s42eyWxPOH+iIlYHRIDqFzY0T4uauXG3vqt0JfPRWxdBcvfSemczG/IaQe86PABaF
h2ySHCkQJOoPTPAp/1mgk82WTy1zuXcf+i6rh6dnFtS/qFFHiGHW6IEegm2OW3K3YN7JbJFH2Tms
XZBKa9DOUZjJM2d0JqfEw7OIwvEj6lWZKJK2FRe/vEc4+pJKvgQiedlvyzAtRp4xWi9QNfBkhwrL
YM5zxMXUoDRi+qowOHkRsPfldMNeyq1I+jgQK8IX/ysI1WwQURGMlq66QY4nbbmoEok6SVzH/ppM
Ibm/+n/njljOIa6T6lBYw1mI/euBByl3wSP+9an2vKr2NGxAxOWVdGJqBev76FRqMwpt8KsD64AM
9+B9Fsx9EbdvPBRXDZ39dty76+7RVuVBmRugJT/Bxis9nLaNPt1nov0eSK32vT/U8buKDbYqVz0Y
QUNf2/bP0rqBWP++rJtVFhkoLebm4BQ/V93hnKzgs8JZndot0fQJV10sGHrB4a3hnzY/28gbbuXo
nihqFtOAUrO25lcC/dfMY8Du3TgQahzuADd1EvOF8/RbHLPdJJIOaUxPBRfokSvPMwlE0U1rPG7/
XWgKLt5etqkaBWeYWLJjzMs58YrP5vT8UsqCknHNXz/vkLXGHtKM6DUG3dB0bEZu3o4oXYsgbvch
uyFrKlDHOJU7EbAA8qdds9Ymo8RkQ8K2JuhIEtaNkVeiWCwRdI1vu+7B/bp38dczhfYogjBRZpsP
AE5g/I3HwgzW+CYcKcRQavkBBmVOwcUhdaWAD7p3tdjEi5dvDYyfICiY7FTifZioYxMAFZydsPMU
WIn4osJ3bkTRsXZQ4VadTBjDg4IYqbwp9w9jYFQq/hjTER47XRtaXGJNoOcn9j9SGc6L6gOSJoKb
yMCnCWRoDSbf4m4plmwIXUg/wYYvInf+tZ6mlFD8fVCQVf2FwK0V7oSNn3EVT+iv06hHWXh6Vlul
0CtGtwxIt8D/DmCQ2gBox59WJJAvXkKq8GahFWAE1URnQOAvm/BjINm+9GLLuGhwUXhGu0q5Tpc2
pRh5OdMihY329QYm1yj5hJ+4MhjianwvBSs9gXYcZ378m3vxyBSSWPZaNLskXaIe2pTwFYKz8AAE
BwcRI0996kTqjZnxYhnCxavCK07DR90NJV9Wt790aeVAYn6V/1Wy3lBUqijxXUwwN/SB38NjDrH+
CHe+EtJAd+evMUKxsKuG4Sa9U03G6xd8HGrn7I65WedOOKN/qtX5sdxt6Bq9LKxddjl0bHysqg1h
B+qGSlOhhYAxzWzbrWlpmvW2jTrEZsUWO5Mg0gPsbBo576LYpCD9NkQmV48lVKuiW9PeHkDqU8/K
+MuEHq3uasXMsk6CxA9URZw1v41tcSu/CYVD7rOHGkCmZYgZL2wiQd0fP8qW26EJrhskzUzIyBcQ
ebYsJrC4bnGdebO6K8+X9GbvkS7y+rwIFvifROO3D7uSHsTUFRsnpS0dOagCEY0LtPEC5mPuKt6x
xtVxUL0Y2WjzLilD4E1041MgNFZth1MxoXRJ5JSlFhjW0PhREwMGvcpxaZW2BFLq/lncxi62esCW
/ccfm7s24KEto1Per8+gm3NmJ0nI/wxEZH0Q8KNEfalgv0S5c9Sw+A5dJRay1GkWKN2tIdVtCnKD
QhJFgIVxGtGcpqCTgB3bguF36hw42aaCqdRp2h75ZlHKlVP3lHEvNEwjeFVLdy8hBWG8NVI7NFfj
PwvpKhuX41/jWE0XSGrvdWeBkIchiJ86hJgbT7xmDhGB2biTKcIf3q5hQuhWZgVrQbz5DTff5dCk
w+Aa7SZZ9qFArJseCQ4sbJXdBP2uhFmjGDT+9UaCuVf0o15n5vDGQQ4H6aB3COUM2X7rRdLJRuCY
s0DqSgLDPjkni1fJxes0iNOJxYQQqktEq1A2KBZICyvHsuY0K3stviPUIqNIg023j5auar8pK0j/
LRM7itVseo7sdbFByMb1MWQ1lZIlbZPdwSHeYo7UPvo44goxXSTMeX4IrQfZ8d+skLtJMu3aIE4p
osHlcJnvInkOz1E45CIymI/QvG0JdCoov7UMCq3WzOjfaVM/GvjYLRtrZ6HXJIkE6/BPvBbWKkNs
KFs7Ynun7zNJCxu3yeDEGY3z5L1WnsdTZhrWf+3m8uAbWBAKPDdfER7zq4ZiE8x+bA5BvwGoIIp/
ob6xoNysB4adr9F0ODMXH4mwh0PK8nlv3TiobHvMvQOvF6Z5wZrVYmMHDI04bK4+C7sKrL3Gqor2
tqZ47mFPWJY6PWRwXMfW5NZ+BVp6Hp3vNCGH/H/KsqON2f2RkHb/UdzUUIj85rND4N9ZJFNJ9dsT
YagnpJ2sn7TLXEITvGM//Cf8mSdyOBGkcrozJei9zI5aVhutZLJq0K6yKKC3IEgJHS1aC0Duajst
+oeocfx7qU5OaWoY7Iwj3KOO9u5jwrXcj4ojH6pQx/LAWfG6CRd1MnOwRMmZi3bgFUYP48zvvi+3
anGQfj3+C8JOCg9Um0640VpljQs/oZN67Blz5iQC+NDHxKhqmY68LdHZs/aNgcXS+mHsesD2QxyA
/fpjqpBWt5RC8z3UKL7WMTA8rWjPC0EjCcecn1WjSwY9lwP2kQ3jCta28712mGiAOicVNq10Tfhp
J0VIGIAaMSnNUdmP+FF6t/pPB+MVyy1Zw949v1for62Raai8yw/+NkfUp7CilgO+vmm07s36K5RO
wRtATsTe6vAw5Rru0yVeO7m+S8J3JKT2SomgLfDkJ/BjXWlJLEwUycNgqfYkoozwnce8k7aPHB8W
xJtzG+u80yl2IOztBug8pE+gt8Oepk+x/MMW/AzoAYWFi5zRG9q2zUbOpIcyRiMvtn9uvEYiYU9X
0WOjYWH2Jj0QARDNXr8rCoC0WX/DO10Yg7qnG0fWjnzENHk/pnee9hA6utKKfSwKuo2qMzmTwYLv
Skqi62z10OSnYz1rvNrF/BHOT76dDk7cA+DcYJGz6u8/hlp4VKaUCelgXOK7tkHcC1bnuvNXTbZm
77DY1fR2xnsALnK9sn882sC9gqXXdNyc8GsNPrCzQd6jAkYYMhpyouNAkYG/LDEl9VOx0AMtZYhF
s6Msi3x8MdW5K9W0ReKS/37+giNxa6+L/ipqsBopq8SYwpGfXxZZp6ib+FxVJ3vUbw4Iqa9insZ5
hrOHisfmi4nfj1BtQs46xgtPTrh9EGzExqiFIMQfCrwmNbt2o9iAtvWGrFfxAeU+mXuLnnBWMauI
MZUJUFESPKLtmes7Gbjs2VRCXOR6i6lwPpHjpYsTip43J62wmDw22XYvK4Xy+9nxh7WbeT5G3bwX
e8QuUvocDhy680hOjgg1G6UsXB9bFTFNUeVgrT3oe6PyiyAYEYzYr2oLwo+2W2PFKft+za5G2Pgj
pc8pWf26ctbtaRZGDJWa/m8PtFmLd46SGF8C6HNjit0YAbDKqsqBZ2Ed8tt8XUx6HebnFqE7sfrz
G6xdjsP91lPyDAnzu1hzeegXMEMbpO735qkwVcEH/O+7znT7Q/3Dq014rHnA5bEY5BX60/c2sFAF
GUm0LJ3aEpxduplCecjie7ZrhttxANtodnV94tPBTQOBYk5HsaGAb6SQdjcvQxqwfS4nsSNsy2mG
XMxiB80Zib9T61k6yqAck1ZZ4k8JflDkkEBaTC4lE3z0ON16oLkh/dd+zZT+JQa7MJnV42YelDXQ
asSJppZQfBScuKI1FWyFm2gck0mxJ0Xdwno9OFK0hkfoivzswuwC9bAxr+ZBU6zi6ba7GOiJ4KCO
EyDDYG0193PlHjIMgEEVnk0O0npAHEDKdUOgtzJPfQVPQ/2mdGp1HlMMaP7B+jPWjUrYGThHbxC2
NP6RX4wDK/osIfpzb7V2gn6wmlXrEUoNIE5roGf7Pq8gLeYPHfk1Tu1GFpVHJFJIPQmL2NT9v01A
nrBqll1/epzD/o/Y75KNq5H3G8I3x9pxoWADRDRPIBzb2wXETVTY5EmGM1xg1/P5sm3J2y4pgZuV
9ItDpsrCmYx+iZLlZz/zFirBsreR6n5PCV0VIw/SXjjo2TgSe1Rdwo5DCJt5HPpmC3Jv7onX1izc
yQNLXHdn1lHyhluL+0Uj0ZnK1YDMJ4vjfbnatZv38UcPNe1jt7duiXbed+sawoyQ5FcV0oKNF7tE
+Xo8WYsjcXnrjFs9ka0trRcvinAsvLn8aaqsTbW2MfH/NGBF0Wep0Ep433D3gXimrdNxZKstMGOe
TeK7YOGqOCWXIPOd5FMtqILSzbANzuuK9azKdwcrFIIrE1QSBiDY+0RzMI6ot1Hsx0VBMoHJ+qLE
QUi4xkLhGcTiaitmWBkLdKxkdbfYF6faSnDVfviqw6V95SJun8PJpzd0GyGztwiuLD2+0ONX3f/k
5eb8teh5Z1XI6rE68bT7zuV7bZwa+uRRB7Wzkt6BzrxJMMocNQfibJ621vGHv+99qFpTovhpXoab
YqnW8McRGHfJqe7EMA/2q41PyWsbkbjpYV39tXLd2voM5dWkihse8hhX5im+Z9Dglf800Prh6KwB
C8ZQbXkDsUhckdlLwKIXcbvt650+58+R+bupJXtxG2Qhn9Ux6pyl7ojgtOBIGF1chPZMqZF/Pd0R
F/3Pl25pU3OgLX/+DYklR2eAJKokSzasv2JrJC0CRCNd75aahfqnrM21wwAeHdZcSZjFpN2Q6sYd
+Cqwsda/6ZM+2zn1f0CHFmdUDBnDnp9dNXgUHn8I48zxdx+DVPd1H9CRlseLghgOHHzS1Lb3Gryu
Y85pSAUWQtGe+KVBqZqoJCo1RIcwufgn4LyBkxtw6Zn7Bmcts7jxbpnjeZPCmWt9ue2qhbvBPCgy
u9fWUStVhsTn2cK+Xh7r+JarHIAezHuh0dxZJTo7Qi2JjkGXM2CCbnr+4SLUp/q7+hKo3nwWEtS4
Ct9dh4gpVIhtLS1XU/kMRIMMKrK3xqCABYQ+ad2xrBftLH0yKWAqS1lA+Up79fYXAbMCbrjOcVxZ
4WD2cDJvcinILFfYgpi5Sfn3MD04QS0wOC3ozX/dB1s641dwhgtIF5hpXeXZOe1lYuk6YmUjILDe
+MflCWhDCzo7lE2u+g3ZiDyRv3j2MjHFU8MFM9F3hWGh6008pRjL0JlePlNeglzayUXNSqU9R43v
J3XUAey5yjuiMS2OZWT1hn6HJj/Afm3K/41SlxXK9x8To0C6iExD+9fV+Z8Sx6xx7df1bD68Vou6
mDxrWPWoZMkwA4sMTJxNb040cm19wo2I7NCThCRoM6yFmyYBoqiW8Lbgc98SRyk7v2JB6lauO273
6OkrXEci66WfJDCs86VJ73kaIzDuPxH7KWQvRpPPYZYxG7xf0JUt8kYArE7+B9rQ9dPUUgkjihi4
1VXHn4La2ieLWL7DQuak10xQ8unzdDyaZklOjE4cvxxjCvUx4KkRx0WMHJO5VH0sjqfHpDQY+42k
cmzAUURlv+5SjgB+Cqy6dtb5eboRXirrty8NvGBrSjR+pfIW9NR01s86EPX7GS5ZkfNVmyt/BiM2
nF/0l662g8UOGK6jp/uM1JbBh6zp7UYo2hF8Hf2DVhzhu9tU7+Ig9APer75MgA8ePRzL/lP4IVI7
rizwKbDtF3+jojRMLFTh4mAJTAPQb7FbzVCRGKdWAqACxIR5OMqTnhz5IqHYl/j5S+dKgcOP4yp4
6RcZC7AiQyIH9hi/LDxz6xeWuFvLh263DCG0XKYu9qSdvFCUMJtsEOTuA9W56RBJltohw37Rxvp9
FzojQskf79YBpGtloXt3062gZEOr2a6sikQ147mnjC+md6ftfWnua/YvL0o+0m/pZwjUts4UEFv2
wbgIKsDxymFuwjd003wOQIQMVhneGgj9yTuRVj0VR6L8Uorr6KhaFcFWWzStVBkWPVWfUMinTVEh
9nsUiuyL5Ca6Mb4rZpOXubsGMRN/0VXkg96AW8yY7Kd01kmZ48JEG42WWdcw0lMkPHrhO55203IA
mZTi2983dwSC7ct40xHg66TvnPKI1tc3MF/ONHNvgDHzKu8A7aiiXdWKXaXQzHm1W/GdF7BO7U21
5l/9wL3nKLdR4LsOs9JsLneL5n0FgzW+0OPz/aLlkzEXmmlPIjuBdVC2tXZFCLyZ0Fp8AMv+Y0MW
jG+8CFIjAXnAW+Rb1GS0UXsIDqlHbwgjLljBkXG518pBU30dlZWavZxV5QDRJ9rbsxktoEGIMWW5
PaC/mKtI61vNvH882zI+8ao1HGRhDRljmLj3jkLKPErns4d1lcUgYpn4hLNqBoXuPVSiBgAwhuMB
cW3qgqiO+PWVJsfTHzjVnDAIa/Y7HjA1sVmYvTPpkiRnxon6odA6T0Wa7YXe/sQK1bLkDngxgo0m
oDyYyDwOYPqRDFiEw7e1O63QUiKSuJTrB+mnTWVv44aN4GNAmcQFroJwMpXQOh+LMz3+eqgRxz8y
kGZa3ZMIZj0UsGdHXV0SngHMqV9HlDp6qsiUzeYrt6QjmXOABLKQvhCy5uWbiZkBc9iuir1UaioO
GS2GTSFcXZkZwGUYhOxY38DA/4ZclVK7vATLiYOM66wCX9AjfGx2X7I3sqUTepRTDpzFWpxGO4jr
UQjSFRpXAaXt77IhfZolv3a4x/U0VjvcLdBWzkOLsJFbm1F1l4xA8uLKdV+nB11ns8d36Eqp37np
GJKi8jw2wzLi25SqPvb+0C/lVmndQbnaDyFqgBp8Q7FE1XyhHXMf/448Uv4Rp/SUMAdAd4AfMBbN
QkyA
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
