// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.1 (lin64) Build 5076996 Wed May 22 18:36:09 MDT 2024
// Date        : Thu Nov 19 21:52:22 2026
// Host        : aiden-pc-kubuntu running 64-bit Ubuntu 26.04.1 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/aiden/COMP3601/Assignment/submission/hw/build/vivado/anc.gen/sources_1/ip/mult_gen_1/mult_gen_1_sim_netlist.v
// Design      : mult_gen_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xck26-sfvc784-2LV-c
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "mult_gen_1,mult_gen_v12_0_21,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "mult_gen_v12_0_21,Vivado 2024.1" *) 
(* NotValidForBitStream *)
module mult_gen_1
   (CLK,
    A,
    B,
    CE,
    P);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF p_intf:b_intf:a_intf, ASSOCIATED_RESET sclr, ASSOCIATED_CLKEN ce, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [17:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [25:0]B;
  (* x_interface_info = "xilinx.com:signal:clockenable:1.0 ce_intf CE" *) (* x_interface_parameter = "XIL_INTERFACENAME ce_intf, POLARITY ACTIVE_HIGH" *) input CE;
  (* x_interface_info = "xilinx.com:signal:data:1.0 p_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME p_intf, LAYERED_METADATA undef" *) output [43:0]P;

  wire [17:0]A;
  wire [25:0]B;
  wire CE;
  wire CLK;
  wire [43:0]P;
  wire [47:0]NLW_U0_PCASC_UNCONNECTED;
  wire [47:0]NLW_U0_PCASC_EXT_UNCONNECTED;
  wire [1:0]NLW_U0_ZERO_DETECT_UNCONNECTED;

  (* C_A_TYPE = "0" *) 
  (* C_A_WIDTH = "18" *) 
  (* C_B_TYPE = "0" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "26" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "1" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "3" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "1" *) 
  (* C_OPTIMIZE_GOAL = "1" *) 
  (* C_OUT_HIGH = "43" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "zynquplus" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  mult_gen_1_mult_gen_v12_0_21 U0
       (.A(A),
        .B(B),
        .CE(CE),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_U0_PCASC_UNCONNECTED[47:0]),
        .PCASC_EXT(NLW_U0_PCASC_EXT_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_U0_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
GldLassLiODVgwPWl5GtUvNFVA+ZFVCFDhi7OrBop0rEIGOD7pGMQGd2XL5uXmDjnBa10M9DWskh
bTmllY5ovkWmM+NjjKYtf65BTGkYfwgKQ0A0l0q2oaCRiZEI98rgXRzWg4blHjn3F8mvlotras3b
gty58LDcqChRb34tHz4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YcKo5o/69htYDEreuDNtMbaQmtugz53TAiA3xMek1XTrggXZnceDK+Oacp9AwNeiNftWOxMl66sc
GrZixCPC4jC03qefsJitE5tQCfx9LEom/ln0gke2S5U676zqGFFkGD4igDSppP9+7smsit0JMNFB
3d9nJDwNXaerv07edmo26kGx6IsxHNmGjsmUd8FYgoMDNNDiTN40UA7rfTR1c5FwRoOUAPNW8x7l
lmsL+1mbpRU3rvmnc+tPlMZ9USQRFaWSLPznAatOpRgaHOa1J4DFd6nwIAGf3cDLilhq3YGA2oUb
qXHyz/+dnLIidWUJj1UPrzhk+3OEiFNdeXBKsA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
g4qhHdak8eXxEqdympBtDM13xMJwZUSekBKApv5XlolRI2rR14IEYNQEcKRGlZyuFCmDRJDrEYWf
Eokybg18xq2N2hsq8nA4pvk6H9PXJmnhKoFcPeZ1j9mOnXNuEaOZnL6sA21bsPP7tTakNFG0eaXB
2vlDGYPDupMpXlylpEQ=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YIONylalBSo3oXqXlsOxHxbPAKbTQFLUkNcqhxYuBHSYbie+16iUZHVqekHM1nIPQ8A+NqZHT/Cn
bM+AOf7At893GAAiJmLAoJJQdHh7oO33naeJX4XJ6I+8adw4O4AucHf+iXdDTh+vT4ToH3pNI1H/
fg7BSszZg69zgY/QsPHraQkyFn3n6Pi12TK4KdE5CdqP1IapEJzDzFftP3QIdgztNEm32O7R9UAV
Qu6VW5iu2mw976oaaPRS7xQkeSuh8v3dIBFLuXEUwqgjFtQ1YItY1vsqSSX+qAtcmYqxSAn3rSTu
J315oxld+eYjvTtO32Qn2VPHVzfXPLCqIWAfbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ggUMon3tDyL18D99zI+gQo2KEmq86nD/UnuCl2KfpNz4G8UqOi9eijpYl6B8kVrp4KbnZWqTmMMF
z/O87hlmFpp4opDcOruJ+qiiTBWsOzFIQR4QZlanEjh8iO0cwSFSAz5sXdE77BCjzgHI7D4UD4Mp
5DA2KyFTsWztU8ricXXTuH6tZLNTLcTvHzJkt/DfkjmJrDlkm0eRAXhG0MUvkNsk32qCBY9RY9AF
1rJxG2dj5ZCJ2l/vueboa3iQZt2OeB1EloxrJDFuQtvPAvA65BsTM387sUTttprjm7eb5Tm0FQU5
vVHNxCllfsk9jW0rLIKm7dBRCgOntC9jDiJa0g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
q5sQqbKwLxjG5mFk9qs+sD0CQg8/2B7KTHpwf62hzJF+1CFbVJUQ6go3DO5L0L1mUNINJPIKzaAD
66tkeRifjCdb0XYOSTAxArc1zlCtOMwOn0aTyha/Uq8sc44kv2JFuUoIsn/Tl15lAT4q5PGV1fNq
fyS1evlpX2NGjZCT9kx21/uYFVn1ltB09OkXy1tz0sskN2eMyg54gf1l6cTR+xsVdY2hIoYfIVN9
H8DudSxoFGmVq3nTkLEuIBwpOzIdlqxG/+zUbvpOhAOprRojoI7OuuNVnv8kqbudzrZrZDK0HX1J
I5lc8/JLEOTV1hKGDSaSt1UBFUvr7e8cCqERRg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dpec57YobDtonbQ0UO1SM8G+H4LNYxSkwZ+IOdocIPgFV2eNfdKVGLe5M3kGiFH8cY+OBkva9enL
/OWjF9TA2LAxTndxgG5J0pfUvCDOVC48MZgZnIR8dOHrP7D6LGWfbebBGB9V1IoBt63/ke8Gi6uZ
oukujbRqqhLpZtf77LbVOpOjZYXM0v1IplnrAPnLmHL9Auh/wBXbYFGVV+VhmRndax/hdT5NuXTd
OGVqvHjKXMT4qzPWpaROPHYFYtTWznHqjj27TLk/z5Hdp0nlp4+Ebp4zIwYMnSpg5MVSetpPiSCZ
031Hd1PlF/YfYwbU1r9lJTGrVWMqi/+gd8KaCQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HlE05c2aGsR6rjiuATQqbaTq27Z8ZtyCoeTKodnH2OaArT49PLi5ZL6waWhdrvL68et08IAUs9t+
8aQnVdhvb/0fNHwtevhkpK8kJCPhJmdNdN0DS60RUdlb5/sgSQWjlxx4Yz5wWXrD3w3dhNQaJbzb
PdLh3ZWUZ+ldIzf3OmxXqghMZwvXkPIkeVkEZK5rBVF4df5DItd6+GOemFxXJmppL3ChWMcSlJD6
hgFBtCxft+usPb88sDNxtsPNBhH8Yeq+nZ3gc7A2wXdVKQugUXMV+/6MH4QJagSTzkjs2wVuXfk8
YQcZf8t0t2eS3XkCFdUszXwMtQ8YgrBWqnZp6aSas1JlXWWMk1d316/ym9sdD+dt36sxmIOjr/mr
lNnHAn9fdTEGDWsaXok7ujwI96+Jo6VVX3h+8Qo/6f9dvmB+j9wX01yLiteRc/klH0QWWPFrckTr
rxvZC+0DnkSyRPCISuHF9Op/7iDXfrGDXOIKpGzdPMaHMsKqIpG+QnAb

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fff66ZCQIGGWn4BfihDr7MvimxiiOWXc0eZBNa52g6soH+VWc7Xx3RJ4fuq721E6hCeRxrTK72LX
i9jipHmkI+YxSSUZyntNbeuF7P38Z8QWyEXrCSRJqnLKUeNwU2D2v692GIbbkPNs3o1/p6bS+PZV
fy4p7pkkxRTdZGKmGNuXlDtPr5DhZ0zFptZiF4rQKB5ebp50U6h6HWEJapeIaJRVwy77CM+u0fDT
4A/3o3rPHumuUTiliaQcm/1jofwW8Wyt/fEyoDeskyKFiJxA7nvXRFcO7dw8hnBN2by3mEq8uvFc
fsXjl6FQ6E8njLb3YPebcEhF2fiQl6tfqv3Xsw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TPuKSC49PXr1CyJdt/9jlK1AKgl9KP/2WJFt/Z7vtljlmD6IwyvQTKF40mFUq27M5Fuz/W4X5INe
/y1uccitx3VcJsarTiaoGT9S3DEmWfAhW9Z3EJmLNoB5WF+Gt3VSrbcIFx4bRg1NbAvCsu35cwJ8
qIEuedLHAD9VsRvFu3kQcKMgbKlMKJWQKJUShZN0gC0lrTnoVAzLqEKMNA0qhQg6q9MlU0GGAeTU
4OAGi9IXN69mtGYQcFgRHTN2cuQvbBPQfXj7zjLG/WzUgoqFUvAhtN5JMPKijnF83gwj845lsPtD
BdmC4FzXoM7Od2ck/qbMAIXHv6TTsjznVFUQBg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dz0VP1CnlNHH+A6VEdv/MzTzitzJy9mXlBCOCHhiN+w9HtFx0dUiXe3p32oSt/JL5Z+78HPWFZNr
norYJdshbBxv2VA+Qb4W2FkhsUt+nbeUxZGkOXoHhhGec2Yij8F+xw2PzGlLK+EcjoVFUGoblbgy
lZxtUK/qPijjN/wQqhHPSvrKrho4ht3zcjZjVg8ZVfzx3x04m5pTyiTrTQecuIFEiVC5ZAhCQMxN
lUXGjCmiY2z772Cy8Zi5NhUXuo2561aTzEHBTJmriI9CVs50fIl0kofkrrA0OdX5CS5GkPv09EPz
ZPD7/ZAVOXqA3AlDcqAsaheUQnXkFpEPunVR0w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5744)
`pragma protect data_block
+HFFb3IjmkZMyAU3aOeuweGD+f0QQNafI0IIl47+KD6N+BcILlngHEkOIzs8srCqqnDg1nUbAin7
4005UEtIy46xQpr2lq+U/Wr9CSjAJ6mcRbej9Jnac8xAECrC4COvRMjd98C0B4kk/5YM0yMCOrpc
42uSI+PljVcO+ShzfjbE7Sah0gBU+Dxgwo77abV1kTgOGg2xSfbFNL0RD3nKpZG0SU0d9jSibSOi
UgIC6LCX6wGtEzS5xZnTn8BzDu5alWL1Dk3rQsGz6oGW7aO+T5cxueygN8D2eMY4kFeiEOGIeEsr
ppioesPm/AT4o7s99L0QkSgI0cSxFUMTvAExw14L4lacQpovvLKsE9XCIM+/06jTY1qBbkie0qVN
WAyqJ20mBSgvjkCvBDy4yd1kIFMbSNGRC1vsWclaegYzvl+eIJRo9FjnF0xlokhS8oxz3wtK6CfX
5JYn9YHTTG6tH/6G7qvVVsaSoulMV2FSTkZiEj30KnEr8WCHcwY+IayJ6g3EmXVYYWTP0rxjAqX+
qB0IpOmrFhN5vE/UyfBjDO0il6H+M74Pa9ydzphfQk8QS3MVMqaz+jiebWkdtxXpF1rWvdhY65lS
sF881XaN9Ltl9cCECfc78KSLyR67CWgo++HEWvinXR7hIUaVCEdOZVHJscirc4ZvD4UWcbsVE54F
P4DyUNnPW0GXm+PQcmqMTHRLhDEQCAxhGrvI6vjIkkblIxLguopjlPVlFwFPr+m0j+kaAFqUGl+h
7GmzHLSLhxFK7VFVWSL8Co1i+eKvCFkBS1QGCAgj5wLG0F8uw4wmAu0ltuI+eEKg9tK3fvmMs41t
f6JuTqq2oMVDCOfvvNk+tv+/qgWtW24GxOUhE0yUnDkjP4WhFKYLpZisuEyOiN8lRiY/4HCXWgDe
1s9htsjiGduuhIKzGAfNaN99fKl2/W8oNbjsFy9w0+eZqmGgzoKJSwlEVAtyZdDgGWC2R18PUlYM
hzpZBYSGAW77ipcQ1Ns2OOEnPkdQBBave1CNIc9Nt9LEkSFIXBcUGqiJk6054inK/crDsor+rL7J
DnXnqps3v9x8KigNanjOZWKiI7UN9kNRvoyMhq+7igOPZu5RQ/cke/GHUptswEUnnvpnTPCZZ+u6
4+gXutKYNyx2XhKpqB0Fp7MvgqrMsUA3UQddEgooQeYHSoJ7D2nCif8TC1yxNyS159lMGw+iz4rn
zYZJ+riPZSUKeSWjJ+Mo2aIRgHnOdhW60mSZ7IhbCkk73sudqzmJmWCVotYPe+xn+F5g0YQIUCi2
brGLxFr0WTy3nSNWHxhtn/0TlaNEI89oObL/B42MqYVOB34p/worWQcdShA2zgSK0yF7G67mWPl5
v6Q3coTETyitVPF12gTfv/YlMbGg2DP5BWJ8EpwcLBb+m9H/nzoSTdGX1OvLVSSFu+PVUk2nGCWz
oK19L7YUesCpMPSWO72m62LnLgPHAGhHa5pFf1V4c9JK/0LfdTNLFB/f/tVU9kJ0WsLXvL8j3p5p
uPdxHOALNTbwU/mBgK2JApTD74CH4G/ifw0IPd3uTVkcAa9hLL7Qua9MBBnO6Aj8OeZlrBzbTYck
wtMdQyAdJitjDJ+1zHB56w8XoFbAnJ2T2YaC5ns2NvKFaPZjKFtOx5uytM3UaRtr+xB+dVFukvWo
njpzQRuPyQuZs2Qi4EiJFsOvudic23o9gh7C7qWt9UBKX7/3M8W1ugDU9m+qoCLaZc1hE6WilXrL
zldtMxyFOAZ84GlTjgg3zsVmUhytGiccWGTIrLwGUR1M3gF93TTixrdlLOkYK8mgTyK94ondKg5e
AJEfPKhWnmpkf2BhXFIymyHhi3WO/AxY33CcBrowHZckhX7B31xhBoq9xdiZgAcQYwNiVCEdgaJG
IgE6HVAt0lFDO8f/jMOw1NLGp3rUTemFMtbN0uCYKsmJedxsNFuVzYTLUNaFdZ9ASnmv3A8ydpUq
3QevKwLAOcg87DNo+HbO+T4UDlG6L2By8V29+roy7cl2eRkxLZTraS8v2gFxnYTpDzjkFhOG+7Ig
wiWMXHqTJW3nqcKaJPLs2J6aNHbwOHvl1/Q6rjHB6TP/iOoXoXK/ZrTt0PjqHAPFaE+0YDhWSkuK
1gevDTcGzru/57kDM1H8/Szdg/taSsyF5S2cWE4pfv0HTvDSrJxxwlK18T8mTE+uPLwipW1VoPt3
oHLXfL0VhSNSRD93Oq3t4Cr4hKupprttqHWSGVNaEw8bRusJakT712eJ7zHO2gzTH2/4rFnlKYtn
Zl5t+KZa5CCucpYUwEhLSH4TvqlEFByhAB432dEge868gfHJ1sUTXMP9fq0vmLK1E0iFnXcXMFW0
r6z5JC3JlF+EpMjgS0UoXqfY8IfoCmjOEO/WCntPyWGxENMS0KsaXm1RjapVC9mZ0ycfoY+WI/zr
er6Qku8eZZQI1kUFFjaMbOT5J/7xtCAH70lx/G9I/Rz6sZzrW/gl862h9QCglEkOZ8HH6iI7KkSF
1FDebNpGeTWSnqf2SyJ294pvItDlek2E993rPvIgN4U8L5hgC5Ue1qzygT2EF2U4t8+Dyd52x/YZ
8AMRX8AntveqvYAC4iGJdlT78yf2qIDCyFrzWjGO2ohGv+RuoF+aP1Vgli8f/WhjOeYKCKQkErFe
NMIpzlrOCoWQ11s5A4Z0qeHsvGogwWfNdmmGRghLmnDxmzvIZYLIuuqBk20ojNvfBNEcWqJ/Tj0f
DRxnQDUkBKeJohTeYrc0mdpuSapBPtX5ek5A7NQ7x/jfZSqk5K54e8ia/WTiyTSaFw2ip0rsnZ9c
wpU5UhwN7HB39NdXEXmBgdTblyz7RuDSbLh/duW89v4BgsfZkG0zVuNwqLSe76Z/avOoGvXcRdPe
5hYu9/DiPnINn+U7HN5B6lLhT5kFf4O3LRiBP6Xn3YB3As3zqtJKZXZ9ea4FeoN2bk6uVEglExgH
VWmucGMw5mNzezkuj53R01fWeexILb/7fw094k4aZ4BrI1UsN4N9OoN4v6b2QEBA2R08KcWSvk0k
zSKoAQRuEsJpQmXL1QuQy6tcZMoDHU86J6OmhcnVjmyz8WXjQnfZupB+drx4SAl5toF1+CRPnE7j
TwMSv5N8qH06HkfuQtP7xwcuLJqKiMAOVbwYhV9KtiAUex9pKwd4G7pSadr2CvZGl5+oLt65yK7P
FWu+UmvJGKDQJAkifYElbfmzAxtlEXQPUwYoDdjeUjoFKcjdMya2LgLXqpu0mhO+ElB7JSpi4GXk
BcMn68WiFD9T31X3sFTJP1RCUnhSSqaAL45l/5yDiGnjqNLpV/rKunVgiLt2Aaer+p42WAkpk7HV
/4FnBpxvU7B+wxrzIP9xAXYzA+urrTwWdA+IcqwG3BtXerqAGooeZoFBnlN1w6lCDig68uf4eI6c
PEwf5wGYJ+wpD5CvSK7MPzHYAU6+23A9CXAh3JVVDePfCUJkLXSHUnuT77aagRAqn62ESr2g8YOw
Euk0ORTYnjdrb24/wRQrC5RcAEwMnQTfXp7bqV+aIFjYZSRCGqfeR2riRfh2O57x7hE2SkxXGyOO
sgSXD/aVNylutH+pGqeZapBnfqdweGIzaww1Rb1yRWJahjhtUNE+8zu/tnKuS/uftnvSb4ueLZDY
C5TFIH+oewtAUGoBZwDBD2m5KCZarNGvo/J92NTtBfZCES+Op4/aKZ1bNZx+liET4NFGqPr+zZRa
XqAab2qU+QNXmgiuuegCBWoUGVvDz0tvqNLpcOi6RrZ3MciZ913oGNuqDy5/d0c1y1hdsxm9aW1G
xp/RSn1wv0Njj55C5GpiYm8m8l4Hp7FIvG0nQl7XcRNK2jLEizpfL2Gw5CzBQsxBbb3oyl/5Wws+
XtPDgcI812p8JOmTMzk/pqlybMzqaddmAWTCWJlUhgmkJIL4H+6HEh7SBqzvpF3Nhmb929E8kgNQ
KfOmrSEahc28wPIAQXC0Pkkz+uqHxNqm3sB613yVCinN8vSB29zrAy5A35JP6pBsTK2V4kFztWNV
p710BJYqZIJ9ipr/XCfH6EhPKTIumAXP5rQeQd1VAWuW/gsGLM4HNS9HqZcMbThJaE07C4E+XXfn
hZBRXFIHOjxi3/AvisxdKA423CFgqf+QqkpeiYPWwx7GJiujY7YmQSImAOm7O5EnBa45asVXyPJh
nUXRm5XV73sR4irsg/sFboxwFbiMgBCMgWBp77c94i81VqZo6Td6mQpMaGnIJvdP/c8DTNGifNQj
4v88MHT3QpVtBnsc2efibaKsryIovK1MpD6aR9GWjSFfZ+Sf5pg1SV8vsNp7V6lP/kFsr5G+YpXY
E14ehmmx1qWcHE1qQb/LuxYkPsaBSTMn+MmhxIRnsOOLtZ8cXA1tAZRSUc9+5WYfXQAELE1lu1g/
sWxDx9uQquXl2NZ9+8xWaPlFxjfOstm1OusxENylET9L9xubeyHt4tKrmi8Kx3X8O5DGpE8rGOHF
4c//mzGNBSYXI41t/NP1nsei4fx/2CjlWd78JGleKUZyZRxIpS87LazP8pKZru/2qVcf2FrXpC0e
QBoIO1rTtifn47F7ASVI5xTtm0HmEq4xBqn2PrIoVsJTX+4YoB8m3qmKKAaKT1CAs7hiJ83FDPE8
08NL9OYTnsoXTvXEaGApl5wpu0H5tWRFpKLpqqdCrAUgkULyi8k1fJIetHsjc2Jh5NzKgI+/a4ZV
FU2l6k9pNacPmgGH0eYL2hDf9w2GnzQqN++VEIMZ4//RvcZTs7Iwi77PsAPTlcCDOmvCyheJag57
WZ+wiosPvSywEViMXHoWx6eU8eUKHjRPr15deO4GGxypZeJLg4hp7jMcrgrJW7GJjpmpMwijYPNL
dbKteMYXbGia3NMIa3QlgRYeND1YSUWBOoKQG7fhYf+K1tFPwUWTZjc2N4VmZEt3csBtmjGMrvbP
ZZqEpMw4chn5f38g7tIegeLWBpgo9G2OJPxRo33JZ93kGfSR676z32h5KWq/akd1MMeYslNBqmH3
oO+1ZlkdZ+ZZ/81W7qTQ14EPdbFda87ZJIbb4e+PV5VfUVSzBNa2wC7ozqAMmRPb1k9OLL+l8DjR
AG3cciz+Cpy3dZgzF2oFqIKSzyiGwvwMdvuGnIsRr/tymOGT56sI+zlcjbM418eVzVo5dSQuu5Qb
lTUbBugdauNblMSznDILRMWt+1NU/gt/YzHk9vWpc7ig+lh994BEX+44dmCLvbaf4m22Qog290Mf
E7JT95tp0gWoBHY1Ymqf87P8zs8R+ghht74JbklVfoURxr6A0q7s23qPxO7/FFTmnKEwhiPsrEtB
leiZ8IUn8ho6TA5v5yyXYr1T/cmluG9ta2/nrawChKKp2cock1Bi7CpMlmZBks+hSSK9MS3lltde
HWBABU2kZOK/zCXYRepdJxOLMPwjajkBfp4dAt19wxrhTH12p2OZyLKQRW397wAnTh+O+o/OCv1a
YJwO/NaqXuQQzba2vUM6hjGKss3jsC7txZWpObJC9BfhepHcPb7a2lki/lmtPON9m2K6zBY25rE9
9GM9jgkvjjCMa4Kgr25Fc9rY72JeL/AIl/ooYH6nsFRDzxG8gzskSLue2TmUacIJqM3+8+kj3tux
3rUz3XnNRib3QGZfUCW7otZicDR4rn1jNJGVGNNTtwXkuSwq8MYg8wKREzmag3GEysKkUnnwfZ85
DODf14VUiLKnn9QHe4y/SHX1WishwJa2n0IJ/QFBXge5OTgCVhZkwxwYKpQD4/qvoWKfSMQDrkYa
JQfcqff5eeaLjwFMvCHx4yBbaYgCf01I1GTCJ/ahCyI7MjJfzK3T0xfJ3dKA3Ir4/tQP1+qf2mBK
vLLcw1nsTY3gd3By+TwDu2cu2pod1FHZkUmNXTnLxJPj58VvzKJLIxEZyMyk3lW8m/uMh0EtX/oJ
MQnlFq+mVqYlVzL4wa3J1fuF99eMftDImDRsfTUqHxxDmGl3uQDvBpapHl6On6zGmkNOTcjJFy2c
avOBFycN9DL4A7REpxlxoqVy9hDIfb16Ve9bcgQHzrwnWx8WXK6odrW4KR4MablJwV9Mh4aVeg3A
D/i+mu29M6149ri8XTxkFq1AvAb1xwkvLMhuROlUSB6J4ezT5S/s2rifZ4J8fyNQ9WL7a9Bh2FDa
UPfHdYuzmLsCHf5cdn/0weFF2jBwMlYU0HVw2/taobx/KDQ9hG1NpVIjjJE8wHdt4s1euql/T1RW
ZEbt9vdcO4zel2FdA0WNYxfa/Ukfr3X0ClMfWBOjVnQ1neqzQFyRlvU22DWMapBkmnsSqb2aI8af
cY4tpXkkVYhllmk/GngOUVHcIDFA+NiZBbVu6lsxSt9Sfr0xnDE326cwnrKUExfLdediFQmrGFs6
WfFbKXCWwf4n8XdsbbcpeV1ytuTFSNy92X3uvOabR1V0x3YrCdLFqkdqBftFY72IxPFiJW131/5w
7AdMe9ZNrkzU7mudtpe0Pe7wlSQlx6ahMbiZIrYuQzNqvSxyB4YpptdjhirT/vBvKz5inw0u4i9k
2xkubAzsv5cA+v8elxfkD4l79zrh0D7zqDwhOSTfnsW8awcnRLZaieY1GQpLlBC0ceHsBMSndouG
LYGtHskrKckyrzrev4G+4fkEUP92bBwKg+P3Bu2RLpdQYa6D++EhnJ1wGwMlF+Qnn3YjfOodq2t6
0LXgAN3qancoCiZGLzgjZC6dz9f1OKdE6Q/nlNR4GUcRmDUXqYvl9d+sturnIiirMRvzhJZF1Ya7
dTCk+Hhb86Q6GgJnby7bGs+HDmus0fZ/tYSmGBz0azAULuFsVf83+S9GRIKS7TmQTakJjwmkhlwd
nFugqm5d1ERwYasXY9qfeSVBtK8AiGmTlTn+VFZlFrEl/m2QWg/pnujUrGXI9fg5GiwuSt8nSMAL
jR2O8U5JZg0xI+UgnCyEPMEle+RfSfFBo6W97Gv2bU6ERnkvPx53XCwgpwLkQGiPHwiRNZGnYjYK
ufFfMYDJKpwqrk8WE8j9gZVmtxZ1hKtmN63DqAqgd7Nx6/jkRgsCjxj47FxDUDDIQl0vA9CUiBz6
r5rtjkCSPY6vmd4zMX3fOHszeR7FoRKhvwhDMqjGv/YuhDqZeaax8kgSZnvJQc3WwC8ZhZDsrDLE
6DyOnlxRjXfz3i3mKfuFZZ+XAZxTdFxpbIta4bj8TLPOEtthMBdacI0SDIfhAcSwM0EUMtdgDm8u
hozNWpyO/HIE6F31FMK8O/7doWJhAeO3Klmfsydjxeu0PL+xJZkojGW2qyqSeFycFDV7N1ADHvvY
r10f5aYGuSPXTOIC0FSnEUuFIC78Jdjd8/n4hEDMEeQRGevYOthRt4EWcs7PH+KqKQxbqxTAUEc/
BM94rhbN4OZSpAISVQSp+NP3sCYhpOu3urlsc9E6nhp4ArddYq88scNjSD4nP5LmLsRP4L2QImn/
DtE37EqAnJFv7TqpVd9FKFO3eyYLuVZvob7030HZgy4Kpc3ZxcQeRi337sNiL1DDvgtuut9DB1v3
wTMMDl+S+wBPe5INMcM4PhWhnUpfIMLvQZ3d3T71VxqmB/iQEGu8hMquAz3sRQC6eNXyMYCn2JcU
fDT8M3xnfXs7yZQaZoetRDhXuvxB9eA5M7B5v0TGJM5E7K4K7s8XqnwfxFc=
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
GldLassLiODVgwPWl5GtUvNFVA+ZFVCFDhi7OrBop0rEIGOD7pGMQGd2XL5uXmDjnBa10M9DWskh
bTmllY5ovkWmM+NjjKYtf65BTGkYfwgKQ0A0l0q2oaCRiZEI98rgXRzWg4blHjn3F8mvlotras3b
gty58LDcqChRb34tHz4=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YcKo5o/69htYDEreuDNtMbaQmtugz53TAiA3xMek1XTrggXZnceDK+Oacp9AwNeiNftWOxMl66sc
GrZixCPC4jC03qefsJitE5tQCfx9LEom/ln0gke2S5U676zqGFFkGD4igDSppP9+7smsit0JMNFB
3d9nJDwNXaerv07edmo26kGx6IsxHNmGjsmUd8FYgoMDNNDiTN40UA7rfTR1c5FwRoOUAPNW8x7l
lmsL+1mbpRU3rvmnc+tPlMZ9USQRFaWSLPznAatOpRgaHOa1J4DFd6nwIAGf3cDLilhq3YGA2oUb
qXHyz/+dnLIidWUJj1UPrzhk+3OEiFNdeXBKsA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
g4qhHdak8eXxEqdympBtDM13xMJwZUSekBKApv5XlolRI2rR14IEYNQEcKRGlZyuFCmDRJDrEYWf
Eokybg18xq2N2hsq8nA4pvk6H9PXJmnhKoFcPeZ1j9mOnXNuEaOZnL6sA21bsPP7tTakNFG0eaXB
2vlDGYPDupMpXlylpEQ=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YIONylalBSo3oXqXlsOxHxbPAKbTQFLUkNcqhxYuBHSYbie+16iUZHVqekHM1nIPQ8A+NqZHT/Cn
bM+AOf7At893GAAiJmLAoJJQdHh7oO33naeJX4XJ6I+8adw4O4AucHf+iXdDTh+vT4ToH3pNI1H/
fg7BSszZg69zgY/QsPHraQkyFn3n6Pi12TK4KdE5CdqP1IapEJzDzFftP3QIdgztNEm32O7R9UAV
Qu6VW5iu2mw976oaaPRS7xQkeSuh8v3dIBFLuXEUwqgjFtQ1YItY1vsqSSX+qAtcmYqxSAn3rSTu
J315oxld+eYjvTtO32Qn2VPHVzfXPLCqIWAfbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ggUMon3tDyL18D99zI+gQo2KEmq86nD/UnuCl2KfpNz4G8UqOi9eijpYl6B8kVrp4KbnZWqTmMMF
z/O87hlmFpp4opDcOruJ+qiiTBWsOzFIQR4QZlanEjh8iO0cwSFSAz5sXdE77BCjzgHI7D4UD4Mp
5DA2KyFTsWztU8ricXXTuH6tZLNTLcTvHzJkt/DfkjmJrDlkm0eRAXhG0MUvkNsk32qCBY9RY9AF
1rJxG2dj5ZCJ2l/vueboa3iQZt2OeB1EloxrJDFuQtvPAvA65BsTM387sUTttprjm7eb5Tm0FQU5
vVHNxCllfsk9jW0rLIKm7dBRCgOntC9jDiJa0g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
q5sQqbKwLxjG5mFk9qs+sD0CQg8/2B7KTHpwf62hzJF+1CFbVJUQ6go3DO5L0L1mUNINJPIKzaAD
66tkeRifjCdb0XYOSTAxArc1zlCtOMwOn0aTyha/Uq8sc44kv2JFuUoIsn/Tl15lAT4q5PGV1fNq
fyS1evlpX2NGjZCT9kx21/uYFVn1ltB09OkXy1tz0sskN2eMyg54gf1l6cTR+xsVdY2hIoYfIVN9
H8DudSxoFGmVq3nTkLEuIBwpOzIdlqxG/+zUbvpOhAOprRojoI7OuuNVnv8kqbudzrZrZDK0HX1J
I5lc8/JLEOTV1hKGDSaSt1UBFUvr7e8cCqERRg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dpec57YobDtonbQ0UO1SM8G+H4LNYxSkwZ+IOdocIPgFV2eNfdKVGLe5M3kGiFH8cY+OBkva9enL
/OWjF9TA2LAxTndxgG5J0pfUvCDOVC48MZgZnIR8dOHrP7D6LGWfbebBGB9V1IoBt63/ke8Gi6uZ
oukujbRqqhLpZtf77LbVOpOjZYXM0v1IplnrAPnLmHL9Auh/wBXbYFGVV+VhmRndax/hdT5NuXTd
OGVqvHjKXMT4qzPWpaROPHYFYtTWznHqjj27TLk/z5Hdp0nlp4+Ebp4zIwYMnSpg5MVSetpPiSCZ
031Hd1PlF/YfYwbU1r9lJTGrVWMqi/+gd8KaCQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HlE05c2aGsR6rjiuATQqbaTq27Z8ZtyCoeTKodnH2OaArT49PLi5ZL6waWhdrvL68et08IAUs9t+
8aQnVdhvb/0fNHwtevhkpK8kJCPhJmdNdN0DS60RUdlb5/sgSQWjlxx4Yz5wWXrD3w3dhNQaJbzb
PdLh3ZWUZ+ldIzf3OmxXqghMZwvXkPIkeVkEZK5rBVF4df5DItd6+GOemFxXJmppL3ChWMcSlJD6
hgFBtCxft+usPb88sDNxtsPNBhH8Yeq+nZ3gc7A2wXdVKQugUXMV+/6MH4QJagSTzkjs2wVuXfk8
YQcZf8t0t2eS3XkCFdUszXwMtQ8YgrBWqnZp6aSas1JlXWWMk1d316/ym9sdD+dt36sxmIOjr/mr
lNnHAn9fdTEGDWsaXok7ujwI96+Jo6VVX3h+8Qo/6f9dvmB+j9wX01yLiteRc/klH0QWWPFrckTr
rxvZC+0DnkSyRPCISuHF9Op/7iDXfrGDXOIKpGzdPMaHMsKqIpG+QnAb

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fff66ZCQIGGWn4BfihDr7MvimxiiOWXc0eZBNa52g6soH+VWc7Xx3RJ4fuq721E6hCeRxrTK72LX
i9jipHmkI+YxSSUZyntNbeuF7P38Z8QWyEXrCSRJqnLKUeNwU2D2v692GIbbkPNs3o1/p6bS+PZV
fy4p7pkkxRTdZGKmGNuXlDtPr5DhZ0zFptZiF4rQKB5ebp50U6h6HWEJapeIaJRVwy77CM+u0fDT
4A/3o3rPHumuUTiliaQcm/1jofwW8Wyt/fEyoDeskyKFiJxA7nvXRFcO7dw8hnBN2by3mEq8uvFc
fsXjl6FQ6E8njLb3YPebcEhF2fiQl6tfqv3Xsw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TPuKSC49PXr1CyJdt/9jlK1AKgl9KP/2WJFt/Z7vtljlmD6IwyvQTKF40mFUq27M5Fuz/W4X5INe
/y1uccitx3VcJsarTiaoGT9S3DEmWfAhW9Z3EJmLNoB5WF+Gt3VSrbcIFx4bRg1NbAvCsu35cwJ8
qIEuedLHAD9VsRvFu3kQcKMgbKlMKJWQKJUShZN0gC0lrTnoVAzLqEKMNA0qhQg6q9MlU0GGAeTU
4OAGi9IXN69mtGYQcFgRHTN2cuQvbBPQfXj7zjLG/WzUgoqFUvAhtN5JMPKijnF83gwj845lsPtD
BdmC4FzXoM7Od2ck/qbMAIXHv6TTsjznVFUQBg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
dz0VP1CnlNHH+A6VEdv/MzTzitzJy9mXlBCOCHhiN+w9HtFx0dUiXe3p32oSt/JL5Z+78HPWFZNr
norYJdshbBxv2VA+Qb4W2FkhsUt+nbeUxZGkOXoHhhGec2Yij8F+xw2PzGlLK+EcjoVFUGoblbgy
lZxtUK/qPijjN/wQqhHPSvrKrho4ht3zcjZjVg8ZVfzx3x04m5pTyiTrTQecuIFEiVC5ZAhCQMxN
lUXGjCmiY2z772Cy8Zi5NhUXuo2561aTzEHBTJmriI9CVs50fIl0kofkrrA0OdX5CS5GkPv09EPz
ZPD7/ZAVOXqA3AlDcqAsaheUQnXkFpEPunVR0w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 9408)
`pragma protect data_block
+HFFb3IjmkZMyAU3aOeuwbw4jw72vUrONSDvAQXMA9EBYHHi630tXdVyvulBxw5mrzugYov1HWcW
ylpeAibsgLIeoSy3atqN7M7a0hQDBxkN4sh3nvZCg3Ps2jZJjnKPYPzlkUOrvSSKEs8k+bjUvb1A
IaCYr1FZVqDPLHNt1aS8HgBjsENAnSZrzgTW2N19cyRobboBgAjYBj+sOLtonrQ7tt/yWNjlhTm1
rk6JP7VB971hqVK800baActBobsJCt/oAOD7MFd75hIUNdkI6n/3H5BfnmoR68KB6DsBo7rDjjm4
S0yzxKxjcBBEDZH++U/vGAWQEim8xNVA3pUfAN2eutc2k8NAjmOrPKW55V6foW4O/NmpBbKQByyB
+imq7dzHQ87FygRH71PGuLF9qDqJdAzx1VHFIp9V1lhgaQyVurAbPQRWh0jLKGQMWjQRPLAWNuRg
Ojm4756W/I+HWW3HtnPnaUIL5LpP5MzWOTjgVpqDILshDh3ajAil/2Axx4KGJLG1wrc1gYQhsxKk
Z9Qfv7IwfymMCC6f5KFzO4hX1P3bWY7KKleMw89j2HPV218F9GUTNooJNabxo0rBtUhQtlkGQcDb
o5i/Z2FpznaJ7XLBjZhZwQtRmz/Fb4NmnW/inmulGul2enTgjtUQ2lZq//AczTABVwApg1zs37yR
AQPXnikcn20Ek8FucQhkjKhZLzT5yoX2Kl9MQUSDZdwkvM6HbTNPQnlAPCVU+ztJ/n9YYnRJziIj
weD9xWLrhLVcnMRi3DeVW//T8EMJr0DASWX93++6+W3JZmDaNxI9KouCHNgJ/ydl/8KxeSW5BGPD
GL7KvNI5w00NahaSG/7ZilkSkY6UQ7JO02c8NaMwAkacG4TUg9jfEEtph7L3OSwzC81/W2VTsg/g
DOk6AlbNH8+bkYK+uS/3puCUNhAfjWduKpRpHvULeX//oWqvFGkN+NTiGOddCmVCnDXk+0JGAyS1
iO7B6zh/LkalN/V3EZss2Fb0sSDb8sDj778gBiKcFDz2c7aQryIdXmDw/qzcXnQr6kSh33eHp4MM
7O0usRYyug77Y+7PkGTYbTb7cfKDM+l3gC36E30Zrg1Jxw5fM0Fes2o9tjAEo8dcB9h0BVSuQ3Wy
wLdaUVxXcNV6F06NWkdiyTbXnd60khDFbE8eLKmPH2x40P6fPXOiS9PoTzCRv47voCirqUfGzKBC
vWb2JGUdguoOUiTOd7adkeAjXPtFvTekUgmM65OmRv5YFeQMdp9txkaFBQbYgNEHaBeRpzkt1A9A
GnNTGd0HqD38gidDbDjhTORIq+obCWkGj1ft7SOyR8jkW04rNV7n9AnWext/LxovBKHf9M0+ftcW
r//f3vvA4+KkAomIAcdjpS/DKFeIbyficq1YIVB2CvFUDMJs5JEElRqcCsDI2+QHQh51PeQU2H8X
b8v+kAENxPFOxE1pVopSz7NHXwFirFmQkcnHB4XEGzi2m3hPRcS900Nq4gZhDnCJbuHTWv5W7Zam
RAYsxD+L7fnSArGmtalDOINeGpmx2Ofe6cQ3lVPxqEt+DrlaXvyfx9DmXXiWqABRNvLMYxH5R+HF
pk2yS2LrWk7oQYfce4PxWh0UDb7HWlAafHiEMaMbZ/SX+sN7zQ8i6DJEe2PU5GakhiJGSkpEJ+OU
YHtmD94lNmm9pX5sKOq40CFtY8GSCKBBdaGmCnWoJyFKTRx+ykR78rP0Sf8dY7Cr/GXXFgF5iN8Q
encDFduGijzTPirl0AS9IYlfXLOu1uRkz6QN43Fs9FVrwzMqOm7ozWeW/fK7fYPWII/psXYNouMi
33KWlqz88eHKDxgPpmzuiP9yGLaE/pTQKz5efCys1sqBfuU1ph4xEGHXyEWTXIRTocJdLKYP8xfu
uiBmswRx/VoOk87A2OT/Dp81oV4zMK6MKnRj6mUDkItHELvqNkx0Ku+r0riZ87zX+SERQ1i5iVie
iv5eksryOotYpxLQxKE/YwahlAhivjom5E2l6tqisI679U2XWWACpY307cLhIlCfsqE+oeZWlUpj
hiWspIZo0OnzwKTWZYav89IzdZwkShSy5DhWF1ahRpjM4pFS3Vd46EOn54iRJtVwEtfi/SwCddkj
jY9TtFlmhyjmjqvhJ1LICfaeg4dIBWDlDwfdecWZEtRRsFtUdYV75WOl6XkKoJAAh7kpUyPRSZEb
cHR3qPD3wVrH3ZUjbUZDEXbiLtD6TMDrUmkPu07BujKPay6eYmnKu1YWaCL2XuVrCWIlkPAgoxXC
TxvBFHkitjM5zecpMS8ZtgCSNguS8oTbgSi+IXcpXbsjKn/2vk5lno2E9UcGZ3qwMUjda+w8/xgZ
wxnyTRm8USxDUMXBEJQpbpWvhO+Xpi8pi7AYbNkGjMgs1YIRhBBPXjlYjo5eHMMbB8mHWi12EzMF
ffMhmMVNjpLjpDi+k2Q0VbCVdIf8jVDsjID6dgeOHrsgvd5/dPUu5g8/nfscGe8TcbFx1yJL23jv
fPiIZUGscabNLS3k/hEtyATtDD6wy/+PQTHl4Gwa3gBoz4g7MziMG8iSw/cQffM1HdwqKZxYVac3
DsNtxp8pS1emh9yci/7sHprfbD73skRyY8ClBIhcJ3ZnVVu8IruuykhdQchHxcN7jI5//TVV37hd
Muq6cpSBZdaWTJeW1qdsQ1OG0bL6CSajDrpewsigHZlMQ62akygQsjam8Hv+wbehmEtIWi1OTM8Y
2vi1z4dbPOLqkuy7l9LqLJwPw/sbvVZB08mTZskcXjV6Iia8NFXFGxVKn5P4GLYASaaKvfmsbiLF
lFY/FIFZLVjG4Bmfsg6qK1mTTm3ky1NC02z6AHcXExcR+oNJLcUyVhFE4ILRz2ydaStGj/UIahNi
6NcxtM/6Bqzox3xeqQk5nd/Ja8LJV7zbB1zcyla5jgfF7ZhoHA1fUF5CWQhmBsPrn4G+IMIXikI6
mCKNJJ7cCmbAmHl7323/AvfwhOvMohRxKk4UrOibuBR41PWobZuDEhTheiE4HlgVRvR5Kc6pmdz8
zS7foDC1aNgiq8LaLghuVS8yoiFh4BLnMMKQoP82etRym9abcy7HLoCF6on+KChluoSNBWY5M5ny
c2nuAqC4aC4hLzctuqmYt/ASmHkWvS8QkHYcqKFrxEuOKwVG3y2mqqg+BrkuNWcpvn2IJdBV+Oln
2ZgrtSdEpTB/jmxbH7sitzENHiFjDS7SJDJi2GnXGWSGjXpiQFBhaLWaHWP9HWkuE30cnJ/DbzBh
d4a0fjp7UqnLPOn1eJoyvC6bzV1ZGzrRKmkjWl1W+3A5j65XrMJCsc7HibKyObVlBvajxH1pfnK5
Gk9CUHJdDAlsuyP1oCa3rZXkomBjlAKWK2Tbe2IO7QFkz7hOM06+SNTsTFlr8BLmyH4uXymFA4v6
ZvSgK28v7xeVGznG8HNUK992YVJ9XaxBH3C71qVbW1wqPPnLvUkHNLpoSDtKYOhzCQBDjva2zMQz
YoNH4DOwTM9Ioz/YW9ukv/MctdGBSXgsfySSFuQneg0mRgz1aVFMv0vGUC14y/pvmAavJP8OLk4L
6TM7tlwLyzM9T62abG2c+Rs7GMWwrPkIGo2v4Sf3a6b99jQEc/l1JVVVdRvVL7JOjm1Q0uhuXI71
G/WFcELCa1mpwuNmSNe/q9fw2r8uU3ggeElewTGKeY9xW9C9j1iSP4HxG0m634UM+WeDn1StAzNA
wAMHyr41KUvZPsAnd7O8Qj5l1u+E+byGHubyQRi6PyLcnAjcQV821eNJdkVlwO2eTFVMzoKIFG9/
WZdeqZS6Z8pltaWU9jmbUPO5Nw3Is3K4FgLKVx+g/4+FeojlnmDoDbfq5fOKTQuwM+N4E+BomGFc
VbGAviUiBSvAOF7u22Tp4myRnkN9AL1usphe3KMP477m2o6Q9ltwX131APQMMMwuk4JLPP1SDB0g
hJ2oWY+EDn4e1+uxGcws/CPhMjfjdhOAL5Nqk5dFK0ZzC/ILdQlnhewYQw5BH9f+zd585JYoDMS9
ldIpMVPv+4w/Vr90aMdC8bDEj4XoskC1Pd2ILNe1AYxmAxwk7I6/AFuO5WrjPfSI7SohOeam0yrn
DyZr7i/N8ccyNtY26JWsPSTs4Tw6FDNplCwZqsghgP5jcFITm9h97xrN8c3ma+y6HKr7klkpSt3c
NSsalqnDYD4ssX3/gxrN0UqmYw3WajOWBEI9QGdf1RDLwG3Xt0QyejAWjfCGe5GvRanh7MbBlDPx
Irq27Wz7ME1OJXYbFhJpP/n5NpiRgOA9nM3i0aRwFdvdn5bnkSytjzdWa/+59vW+fYBpsvpmAIKe
U6beuQv2oqpPJxCVB5m+oWWu1wK2cUVGi1tfE1wS4kZ0b3wTpidBLZfpgtKdaM9eMovt1UPgsY8R
HOMFlAJPDBd2e6ZgMm6jF0Y0teoo5hOUD6L9mO1ksTSFTaoQquggIH1tMPw8/zNQEekNR8oOaq/c
UUGQ+61usYBnX2n+X/aSlzLCFF7Mm89VLNAiN/po2heWha+5n7R9MzDYf2v2hJ80G3ioijrtd8Bd
+jwVKsZJ97zMC9w6SUGlmdv6tYapBZZJc5M9Z03i6CM0n20uU6vL5IGb+nhzPxx0DQVPdDs2C8cq
/HtZ/Y91hwj3j+Dr/oKENuCFk7mZqfFtuatkfqrfhh5OhtX09QAq9wY9WD0lTFUOy64zWylTDsQd
gKKf809qfjgExaSD72OnUzkk6YdstwJR04+udoNkGZgFonKSQCLXPPDsu7LwyFDQKRUUMXBr0L/V
SOqW2rkF3Ea4P7wS+KzFuKir2BvraU3LYa3rhvJgxnCYj7QCvVoxWAsdzH68ouSfGfwND9lATKGd
kEaw76QYd2q1rsMHtFFZRVPRFJcPZc3FA1uERwmmo9jSGN5eaOxSWk+oGI9Dr0cMq1Y+a4Wo0bBq
oI6jb/kwCIZfDh0azqvJbjWg4U9RrdohjeaJ+THj8J24fmmJ9hbJ0z2mxnK2zIddgq1Ev0psR9yq
rLdP3P+jRnyZk8JI932bboVI5LY5EOhzoPc03W3UCZCmBmiRmPlpynQ4hIpT3AwzJ8nAPXbzyLeh
Tr4hrWZAAs39novtUMK1r9dCBFuzb1idxAXJGVpjTRYDtUBLlJztoLwwfqWj4nXMiJpritzQAHfD
CTW//ntCrwPS0VGh1GKYBMeF00Kaf5zPSyoQH6ZjGOkFEJL5t6MfDXGY7Oy8KlqtueR/74AJBMJd
OVKE9FsPiOc5bkK6it0rSFzXIGERr3b3F/fcyOBlZ4I4JkSpCQmfltO52sX3HnzHvXdNm/D348O3
KqbTK3rCP4WIuVhoNd/VS/Ag3UYq4F3kNg+wjnX88+tUfSkk3jIl5/cnC/STqdcJcvkiqXWK0gdE
QYvfI8ez58TB+AYp4yn5jlytXOG5qhBzyEmJOX4BrFzKMlmwZ1vsLwb82ZzA3so9dmScUDNTOdZ+
ihtOKC3NnyLfLXs0BiuNzPFxknzjLqhsecHyfki7pdpGECw9QOUxVjbP6etia1DLxONCm1PI1GRO
tbDgqyhAZkH78cT2+SY9Yy5VEFwx0uZdVau9EJJULEN3EDp3HGy7mwDuhPl/sdTs7Vx1oSqogTdG
ueygS6N//gMZtYlbKYYweiI9NY1rP0Bv9vYRZDZSMafuRZSlfKBMEsxOEjfa3UrzibeYsA1EcIo5
HzA+iYG+U2RONkBGWG4ugM0nQ2A/OlAYRP9fo6hoFbaDINsZEgZzdw/9XVY6PGSgMHj5nWHaMYzB
LoEVG3l6msB6JNTQqOXRUsXsjCuY5M52ZoBbC2CDQRbhhNNrwfdeqkQfR02s6wdr6M5dWkimI8zF
I7Nz3zXvPshXGcbBO8hqzv4A3JVd0DfCAMEyG7SO0ByNaLXVdTpLLWQxsJRycS+xTh+vUIjgrB4y
opOC/DZ6IAhJoxuOLZa5NY0raRNdYeBKAv5URkYjjloGF4JIcNOMYjBuBRj3Zfzytv8CrM+vWUl9
fEN2BACwz2BuTSuGzCNbP74DwHKte6zZlFUt80pBK3iNQCNU0ARyx/cjfGovstKFhp2Ot+kUErOR
fRMb2FzgL38C0iRblk7bNlQo3EH3zAoyhFeleVKNdQ2tyDlLUb+35CvtJzQyvMlNyArVVTBHCk82
8UrlmveLAKxCksm0sY8eZMjPeHupzWJBro4QN8196/v5AUhs4GP9wNs6eOtamOjSwuiaHCx1gLCj
hpPutOJEghI+SjNfRYWit7a7NzU5q8DRgbzI7Z6euPqmBC+QTIUCh31yErmQgqU3k7dKvjeNlCfm
rWz+ib6247jTv/e8xKBeZ9enosYHSCHusgV8D7tuNmYhA6yff9d5Z4YuQ9GuRjqLYOm5/NGGn5RP
fptdwtgYyDqq40m33VVX4PQ7wuEHctBM6hphjkpfm+34FyG9vMyVYZ5laz4/dIokEpRFGktbg+QW
QI8sI7pKuIIWUNdON4DUvHbUZIVVbfUJ0+HFCoSf7qdR0/O0weMewNe8a9v/qwo7C0nwbiZuzTrI
yQmARgE+7Q1fYVg0IqiqR/DDbPlCO0VCmrPp9Eq6D2AvlL4oANuJjZQIC5ltll0Fm3JpPrVaz8qX
nR4eiN4UN97sp0ZGjaOGxPN/Oh/gXlt1c7g3QKeJAfEt6JUbD0dN1SXqzi+l4kDnlLtg5GRYzQKO
Qsjm2qER9gIxUTaAmoEBGtvy57hDeqKVgttevUpUi2CJlgbUR2Reu7NGumdw2KhZVEyl0z/6e6NG
FWpuWnWkTbjHp74Z9PdLdJM8xejvp5/3J7PbnfejXNdALev3QAYuwManjdpa2O+7YQTnx3RYcweP
acKfkfHJ0AVo5mEfxyb3dwAe3ZTAP315X8LSuDW/Vkc26gcj7Q4d3GzGb2LvTKAMCfz575dHUnNH
vpHo6ZHBruqv9ZCBYUbuPJ95hjxnw+udXeBYTMB5PrLb5IvVar/ACFju5SMPUQMJagzi1E3cptoA
UWAVaj2aymKzpVfhFM1vBalSVzXbaKoNZwRELm35938T+gN++P8UFRahiNlUWltwDq9BMK9TNdOx
VaaYfDgWEgA7yZBO4Qt2h6FQUFOQniYcsWWv+CDHchhEsA6zr0eMAcsRn28mcddcemJMA/04n7v/
BwR1dxLmwzJDvEIgTEKKFzsRSD4yCpANT0Ko2NPXlCTt4HlWV59FazYFdnd6w9SCOb5VsfG9zZ0b
pNoafw3JYS/Yh9sByRR9VtoshrbubNqtTJWayYb4ch+gRFkCIqapov9M+PNPQb/7Ab5GgFwBr7JC
RsV2oG9HeA4M7+jgNl0M/w2aKFFjOR5m570EehVp8hnYBuzBORlL855syQcZOXx1kyLfZC+xYj73
doV/SqNfwT9SbNSNduayMUCTmFHNu/BXyKbmmVSDnXBkSvfuSyxD6NcaZNV+x+aFbmHEde9N72bb
LhQUD2RY0wGN2aTJtCeGlhGKEmTTC8tLDSC/KGRoeE32O9rggm48i8ZJncLIkn84VCLKhSAabhwJ
1mssdjqjBBvjz8wLAtJRZ+/QCsT5PA4is6qgZ3Xq/9smZ2G7Mf1IK8Lml0csjMZdT5Qkft3d498l
RY5KKbJITf45D7rhpn7E/iGiA6CAy5KDaiIe+oA5hXmDnXKTaA5yA0Nqki9UxbdHSoExNN0HMkdD
CXNZTcv3cZGmYbnUL+jrbmggsIb1ROfNhjqrqF61BM1M9tLc+0cb6G4L4SHfstQsC2kyXgDTL50P
5LFn/Y9UIvQSFrxGHwB/7fSVQFVIwC8TBVk9BetrqDOnScXNET4cdgYHfeUIO9DZsSkZl4lJZLSh
1hS3vwP6w3kjDxNfHTL1okByVCFEOW+kNfLZ4YYKXGgqWR3ub9UvWjfGlVk/VZQ2lQw4iBFeidxj
1maJv8bgkdIe9RN0PJbHhq0afFrIu/qg5MbQHNCRqimvyHWgM0MQX0ZJxeP2OY802lJBM9XV17Gu
hnUzJFin2cUfFzy97XM7LhTfeYDFdf7DYCmBnZ42Yz+vsvabZ/ywoEjrF/UFCIfgDrsDTJIMxPUx
ke13khV/IcZq28+Bf70rRIQP/Ao5eLnzZd+kCX/J87QzmFpribr6U1bDAD4vytrp+SSAZgybeDOT
rJBwzeiFZPXfIJN554XFRBcdl+6sQzHakNuPl4hU8GpCjAWCnmmMWq0Y0F6Xg2nuU7j38Yy+7GA3
rqJidXelPFLyoj+UCIoSdH3C9qrvdhn3RbmG783DdhT8c/qUhU8ofh5mEw7VvbrJH/GPdRUyeQcU
mPq4v3ax3FDfzq32A7YYj9B41vKs6G2jbp5fYl6ohaI9zWGcG4Ml5yh4cvfcAwSa0MmTk1wddh3+
ctpf3/57wGBk/KkTkQlDeqEVTzjwtdioka+qYnBSCJs5XUPL9SZ7jhu7scvHVa0cEGKuiqOrR34g
kAsLSjUhg9n9B7+p3f5QCd2j+6KUdGlTleG1QLfTcCJtVkqrDEV8OUM3cxOmfYm5BmKMbZJ6QgAC
lwCTa6FWcNUn8DXU7AGenVwppeRouEvdEQ67hNpY2gFh3jo05hT64Ma54b521bG7+7hS0Oip4/y2
AL32qV4noHpbjOoqAtopn+MrE5vPqSYGsfiBdoAdvyhkMTw0LhFxMmzH8fBLsX5PMiKzM8az+4/W
8LTRd9LiYiDoUJm7ozNm3zxucCzxuZF6vGXLJN8AJWJ+N1ttd46SbHTgp05Wicz/z6B7fErFNInp
YwSgblYQDGQVovl9i065Xrd+3olX4/68iS3Jin96OSV2zKFTr6h6ycBvSn357JLjy+l4mHvuSifx
w1HOYIC8KZp73IwdbViPDMCQyuJW0lSy9LwzyRcZDzBbwTNFJn2gn2oY0FvkOj4wScmPr/yfq+ud
Jg7evClpvWwIMlkaaylnjA4hthnH6gfSzD2YzDf+hMfVkC11G7CG0W+r1xaCWG0VtyLtxYMVMgTg
OCdD3anbJeielWc/RPI9JpPfmwp2VIikaeE51UTqbD/EQ5/Whf7abgOo0mGmQ3jcJjBSVBtbOziG
Wd1uz2b5BpKeTM11nLSR7MhWz2k10+rAMVH8z5IujTsTuZjZE951usjasVGRSo8PSRrXG0Fnacd2
GHjOs/lVAVxrl1fYO0nNe+jYOltYm8K5olgPeZpasaldN8hrJR1kukAf44UvGhZ1c6oh8d+PMsu/
jIBnEGDqgmrbKmnwYAq0TeaH4hK8PVFn2D+cIQCNHlGENAb2KfZMrcu6KxalpOa8HqKbbLUdHrBk
Qx4OM47xcThLZwlGc2d10AXPru2wLpOy9XOPk5Vqy2BdEgx5+NxryEsDTxV3j0YXRmYUhnYNXUKf
8/kMtfL6WzAcV6O1jPdNDUsx7HU5irCllgN0w9p+H/dmZSy5IYv/e8XfiL7g3Z3k1zIt58jipjmE
UutxSQh1LFFcjPYPwIqOn+ZnAqbMgZYIKdifu1iufgMA5zZQoiJU8SA7x1f2iZRtqBgYSAjt0Y/i
hiwrRexltQ5TT/Vg2tXp/2StzxfLMMJnO5q0Ca8yoTqufE8Rp6Xa6RH1IenXCsVYD9hXEs3otEZH
zuY+KIyT4oMbOPIyN2DUCFOaWUdgP3DRZVwBt+cJkYQ97js3aRW3bc6L7XhPBib45IuNiH/1fOqg
OQjR487UialQpHowEjFx/GC7VIAHyYN2j3j6Rb5sNf6ixgH0eWfTaWu99SjBem8ZuhS41mPtW+C9
YAPHQG5Np9AI1JLK49h4895O5cZ0mRj0Tp4mYmaZoh1SfzoacUeDyx2m2NxMeGYkM3FnEJSJO+mH
P+AWBOQvCWiIiBFSRsDtu/qu49QeyOj1FtDyJ9QOqdTofOiFOp4x8O9ITMioeBD626i7oAQShQ8B
qWIkA7chgWIJDPfezNdbLIHemjsuBBvh9Zi5gIZVgh2bHZ85mE12HYYOHZaLRBXySBAIJ2M+okkI
LBNaiQofyAb4cA4vkl1vTw8a9d9JewnVDTe2m+L6c8W4HyUQQ82SzHnD7FFBSvGvUbOtMBIi96GL
pytyRKnAznBIOwVv+wdSj6WDLoD4NHUurGUDgIal1xCckOh1Tb7W7h4cUCRiwM9IUY2iMTlwzooZ
gr7x8U6+EkA2z5uOhCJkDwdCen9EJjnkIJDxmiOTo0vSoRUnniJ1qvlhGQDAi07xR6xhWMqAvjWN
zO9178VvyboNTclS0PXGWqxa/Efzzs3xAUhNJ2rpAKTmruoU17HGPscJvlZ0FPt+m7hKHfJumYXY
aCpQ0MzZ+Vsf8btr3l/uTInQgh3ZoYrmuPWTwPJ74eSPJt9f/hN5WF0n3lOxbQfHgWCFxQZ041r6
ZvLJtB8CGav5lHbcgorGyGPjr4g+uq3ngWZVBY3W0TMTISvJ7UnLVxedGryEZ1O47+5k/gXsWnAQ
YqJ7uXM+XcEEbHJ/UjrB2jkNmWmYsTICrKOKzILlv50JHZY8g9ZzbPkVXkwKPt3yQZ95mZpBBOx6
8akEjaU57YztPXEB1mIDvHl9dRyNyzhmg+Jr5aadM2wyuQAAigTIa3KS1M8PSEJ9DIPKGxUg4clO
abE61n9oyMwUOemVhh+EYbDv21r1bthhuvnj8XvdvsZNBkj8kAJBjtCzk8KTw+HNMvw04fclxYkl
BKQT91jUhzWjYOBLItu8IjRVEBkQemIS3uwsQTLw1ZuyB8bMmnND+05DeJS7V8/fKhdzIIBHuHxC
IeUutAstIGhDFYoJbHiDMqDkMMA6EvLcULFvA8q+yV5dAJ5eZ+Rk7uAQiil9/mplj1HT3uXSbpKB
m7vNXYmjm//CvmsDlEOq+sgEEj8fhv98esStbvhfM0Dhb8NttHJ0CxN/iWpbuUZMUL3exngbU7AK
smZrlPnpai1H1EgpIt/dX+pHQxrAOBqLD9mTGevLCAvUTRWQExCqzaQj+Wjhz/1Lzefogq22mjz4
IKLqKFcCRYhZZmxg2184lz+x6lp2jFtYruUzgaCKtbR7QJ/rG2UoTJ6dS3b3oa1SUp3ZKAj6sjBy
9E8MRG6GFm+1OITVpP4FomRTVOrfW+6veVp7mZUxCy56UIP7OS+idZ2K92oi0pleHg+eLO0im33o
TFMjDyThZKliKOfKQFGe8RLq1xFB88t3LMO5p+ZgEepFc8DqZNK/2gk6lEIsLa0Sqbl5mDddbS4J
hYmvfSjcjoFRiVsJhA44TTeUuBEfQXUZHO4WEW81yLn1iZgsoL+pqnJYRiFVW2dxxBWi4vJ43Kiq
oqpIQZQuy44RmcYvj9i8Yn5dP17X3scurqurb7zQ0E/aIDxhLD13LpHhgSse0i4RO3Ey1J4Zr9v2
Jd8ygtLerdVFxRxJBGjXGSV+iV4vY0YIOZdybCSvJ6caCkZxofT0Yy4ouxtmaBsEgpiIzC9L1Dwj
1eiYepgw7oiG3xGtJu66OoZjs6Hg1EdUUHkxbkpvvMF1tylHSPYqOarFwIhKSo/vJKVpv2cIbL8Y
xq7chg7X3av34tDZn0jRTIR2JP95WrlVR19qcSkHC+kegIWIfTnZnCLy9uFSq/WwFTc6ySrovkVK
T4UAsxwEaDb9TkI+HWSep0HfH+TTVDc/qSF+blH+zvud7ou/j9OLEObdXFPZcCZYg6xAReXfGObU
ZurHTxBoZ2ENPOsWImfM6BpZzZfugCx0/DzYKD+8K0IRCkJbLfZWjkOcxf4YBNokrx+HAN57Nz0l
kZgp7dr4dNFD8N6CVf0NTqCpitPrRU3vz8lxIKnnnM3j7v8qePKPtp/Um3gE3+d7C2g/h0Obk73z
d0b3dRfoY0lzRoa5S/ag3ts5a1Aeb4iIcctTVEITx3ej5eJg3WK1B5y41B5eSzQNi7BX5vedmlP1
6oljVOoqc2q5DgocIL1tcK4Ctp9Fk1fkXxx5ORlZ3mSbvXM4B6yhzqwrmNzOfU31ak/2bte6dTE+
pKAnd5qkt8BhEN/dpBXTHFKbOy9VvaAKrt9CQgFKBI4swNytukBcBWp58+6h3HhONeAfR+3buM4y
/gvwU5+8WhVgOyBEkvY7v7sjEtA5Zav+YL216zA3cLQyBBwwkBwBhLVnnswRGpL2fC5uB1p7FBO1
xxUAqZkwNz2hHfcAG6bkYcyW9FATJhfHy1zxAAJUDqlLgsyne1WfdDqaFU+ZjuTlQBixbBPlViBC
eSat6vikQjyNP57uu8yLwRgrdsgeWt2iL7VV4GWvzs3L/Xbbfj/WGtv5XEWIql+PpVdKDsxIY4pO
+ZOBld5jNUcqYqiV0LZK2hAbwRzugSdgsL37JzrsMr9Nicgg2LXJSzDEOtyPBCsjvXMCZLnzzho8
n6uZL3QQ11M7natrODbB/2feojamWqvC+I5suP05uCjAk7Tl7pOsPIYWjWw/aCKHBVytv69LSWyW
IvD8VBAMaeL4K2VLR2CCWJ2vM5h7Kd6oSNNUq/iLnzK9ShIlcYeu4e2uH6jmIDHbWDSLvQYgQ24p
Jidx73yLRH8dezysUzmMx0SlyPMfPN9tDYI6b6yB2rnczdXvyHhwj6wGfvTcgou5js/aPUDb1uHk
qQMa
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
