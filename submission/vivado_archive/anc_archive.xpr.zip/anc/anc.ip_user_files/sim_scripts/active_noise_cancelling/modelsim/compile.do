vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/xpm
vlib modelsim_lib/msim/axi_infrastructure_v1_1_0
vlib modelsim_lib/msim/axi_vip_v1_1_17
vlib modelsim_lib/msim/zynq_ultra_ps_e_vip_v1_0_17
vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/xlconstant_v1_1_9
vlib modelsim_lib/msim/lib_cdc_v1_0_3
vlib modelsim_lib/msim/proc_sys_reset_v5_0_15
vlib modelsim_lib/msim/smartconnect_v1_0
vlib modelsim_lib/msim/axi_register_slice_v2_1_31
vlib modelsim_lib/msim/lib_pkg_v1_0_4
vlib modelsim_lib/msim/fifo_generator_v13_2_10
vlib modelsim_lib/msim/lib_fifo_v1_0_19
vlib modelsim_lib/msim/lib_srl_fifo_v1_0_4
vlib modelsim_lib/msim/axi_datamover_v5_1_33
vlib modelsim_lib/msim/axi_sg_v4_1_18
vlib modelsim_lib/msim/axi_dma_v7_1_32
vlib modelsim_lib/msim/axi_lite_ipif_v3_0_4
vlib modelsim_lib/msim/interrupt_control_v3_1_5
vlib modelsim_lib/msim/axi_gpio_v2_0_33

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap xpm modelsim_lib/msim/xpm
vmap axi_infrastructure_v1_1_0 modelsim_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_17 modelsim_lib/msim/axi_vip_v1_1_17
vmap zynq_ultra_ps_e_vip_v1_0_17 modelsim_lib/msim/zynq_ultra_ps_e_vip_v1_0_17
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap xlconstant_v1_1_9 modelsim_lib/msim/xlconstant_v1_1_9
vmap lib_cdc_v1_0_3 modelsim_lib/msim/lib_cdc_v1_0_3
vmap proc_sys_reset_v5_0_15 modelsim_lib/msim/proc_sys_reset_v5_0_15
vmap smartconnect_v1_0 modelsim_lib/msim/smartconnect_v1_0
vmap axi_register_slice_v2_1_31 modelsim_lib/msim/axi_register_slice_v2_1_31
vmap lib_pkg_v1_0_4 modelsim_lib/msim/lib_pkg_v1_0_4
vmap fifo_generator_v13_2_10 modelsim_lib/msim/fifo_generator_v13_2_10
vmap lib_fifo_v1_0_19 modelsim_lib/msim/lib_fifo_v1_0_19
vmap lib_srl_fifo_v1_0_4 modelsim_lib/msim/lib_srl_fifo_v1_0_4
vmap axi_datamover_v5_1_33 modelsim_lib/msim/axi_datamover_v5_1_33
vmap axi_sg_v4_1_18 modelsim_lib/msim/axi_sg_v4_1_18
vmap axi_dma_v7_1_32 modelsim_lib/msim/axi_dma_v7_1_32
vmap axi_lite_ipif_v3_0_4 modelsim_lib/msim/axi_lite_ipif_v3_0_4
vmap interrupt_control_v3_1_5 modelsim_lib/msim/interrupt_control_v3_1_5
vmap axi_gpio_v2_0_33 modelsim_lib/msim/axi_gpio_v2_0_33

vlog -work xilinx_vip -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"/home/aiden/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_fifo/hdl/xpm_fifo.sv" \
"/home/aiden/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -64 -93  \
"/home/aiden/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0 -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_17 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/4d04/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work zynq_ultra_ps_e_vip_v1_0_17 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl/zynq_ultra_ps_e_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_zynq_ultra_ps_e_0_0/sim/active_noise_cancelling_zynq_ultra_ps_e_0_0_vip_wrapper.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_i2s_master_0/sim/active_noise_cancelling_i2s_master_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/sim/bd_ce8d.v" \

vlog -work xlconstant_v1_1_9 -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/e2d2/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_0/sim/bd_ce8d_one_0.v" \

vcom -work lib_cdc_v1_0_3 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/2a4f/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_15 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/3a26/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_1/sim/bd_ce8d_psr_aclk_0.vhd" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/sc_util_v1_0_vl_rfs.sv" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/3718/hdl/sc_switchboard_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_2/sim/bd_ce8d_arinsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_3/sim/bd_ce8d_rinsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_4/sim/bd_ce8d_awinsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_5/sim/bd_ce8d_winsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_6/sim/bd_ce8d_binsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_7/sim/bd_ce8d_aroutsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_8/sim/bd_ce8d_routsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_9/sim/bd_ce8d_awoutsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_10/sim/bd_ce8d_woutsw_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_11/sim/bd_ce8d_boutsw_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/sc_node_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_12/sim/bd_ce8d_arni_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_13/sim/bd_ce8d_rni_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_14/sim/bd_ce8d_awni_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_15/sim/bd_ce8d_wni_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_16/sim/bd_ce8d_bni_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/98d8/hdl/sc_mmu_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_17/sim/bd_ce8d_s00mmu_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/2da8/hdl/sc_transaction_regulator_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_18/sim/bd_ce8d_s00tr_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a950/hdl/sc_si_converter_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_19/sim/bd_ce8d_s00sic_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/cef3/hdl/sc_axi2sc_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_20/sim/bd_ce8d_s00a2s_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_21/sim/bd_ce8d_sarn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_22/sim/bd_ce8d_srn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_23/sim/bd_ce8d_sawn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_24/sim/bd_ce8d_swn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_25/sim/bd_ce8d_sbn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_26/sim/bd_ce8d_s01mmu_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_27/sim/bd_ce8d_s01tr_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_28/sim/bd_ce8d_s01sic_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_29/sim/bd_ce8d_s01a2s_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_30/sim/bd_ce8d_sarn_1.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_31/sim/bd_ce8d_srn_1.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_32/sim/bd_ce8d_sawn_1.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_33/sim/bd_ce8d_swn_1.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_34/sim/bd_ce8d_sbn_1.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/7f4f/hdl/sc_sc2axi_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_35/sim/bd_ce8d_m00s2a_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_36/sim/bd_ce8d_m00arn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_37/sim/bd_ce8d_m00rn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_38/sim/bd_ce8d_m00awn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_39/sim/bd_ce8d_m00wn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_40/sim/bd_ce8d_m00bn_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/1f04/hdl/sc_exit_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L smartconnect_v1_0 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_41/sim/bd_ce8d_m00e_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_42/sim/bd_ce8d_m01s2a_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_43/sim/bd_ce8d_m01arn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_44/sim/bd_ce8d_m01rn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_45/sim/bd_ce8d_m01awn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_46/sim/bd_ce8d_m01wn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_47/sim/bd_ce8d_m01bn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_48/sim/bd_ce8d_m01e_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_49/sim/bd_ce8d_m02s2a_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_50/sim/bd_ce8d_m02arn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_51/sim/bd_ce8d_m02rn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_52/sim/bd_ce8d_m02awn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_53/sim/bd_ce8d_m02wn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_54/sim/bd_ce8d_m02bn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_55/sim/bd_ce8d_m02e_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_56/sim/bd_ce8d_m03s2a_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_57/sim/bd_ce8d_m03arn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_58/sim/bd_ce8d_m03rn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_59/sim/bd_ce8d_m03awn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_60/sim/bd_ce8d_m03wn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_61/sim/bd_ce8d_m03bn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_62/sim/bd_ce8d_m03e_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_63/sim/bd_ce8d_m04s2a_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_64/sim/bd_ce8d_m04arn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_65/sim/bd_ce8d_m04rn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_66/sim/bd_ce8d_m04awn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_67/sim/bd_ce8d_m04wn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_68/sim/bd_ce8d_m04bn_0.sv" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/bd_0/ip/ip_69/sim/bd_ce8d_m04e_0.sv" \

vlog -work axi_register_slice_v2_1_31 -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/92b2/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_smartconnect_0/sim/active_noise_cancelling_smartconnect_0.v" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_reset_0/sim/active_noise_cancelling_reset_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_amp_i2s_tx_0_0/sim/active_noise_cancelling_amp_i2s_tx_0_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_strobe_to_1_0/sim/active_noise_cancelling_strobe_to_1_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_LSFR_0/sim/active_noise_cancelling_LSFR_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_audio_mux_0/sim/active_noise_cancelling_audio_mux_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_err_adder_0/sim/active_noise_cancelling_err_adder_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_ref_adder_0/sim/active_noise_cancelling_ref_adder_0.v" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_err_audio_pipeline_0/sim/active_noise_cancelling_err_audio_pipeline_0.v" \

vcom -work lib_pkg_v1_0_4 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/8c68/hdl/lib_pkg_v1_0_rfs.vhd" \

vlog -work fifo_generator_v13_2_10 -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/1443/simulation/fifo_generator_vlog_beh.v" \

vcom -work fifo_generator_v13_2_10 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/1443/hdl/fifo_generator_v13_2_rfs.vhd" \

vlog -work fifo_generator_v13_2_10 -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/1443/hdl/fifo_generator_v13_2_rfs.v" \

vcom -work lib_fifo_v1_0_19 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/0a12/hdl/lib_fifo_v1_0_rfs.vhd" \

vcom -work lib_srl_fifo_v1_0_4 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/1e5a/hdl/lib_srl_fifo_v1_0_rfs.vhd" \

vcom -work axi_datamover_v5_1_33 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/bf20/hdl/axi_datamover_v5_1_vh_rfs.vhd" \

vcom -work axi_sg_v4_1_18 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/6f54/hdl/axi_sg_v4_1_rfs.vhd" \

vcom -work axi_dma_v7_1_32 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/8830/hdl/axi_dma_v7_1_vh_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_err_axi_dma_0/sim/active_noise_cancelling_err_axi_dma_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_ref_audio_pipeline_0/sim/active_noise_cancelling_ref_audio_pipeline_0.v" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_ref_axi_dma_0/sim/active_noise_cancelling_ref_axi_dma_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_test_constant_0/sim/active_noise_cancelling_test_constant_0.v" \

vcom -work axi_lite_ipif_v3_0_4 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/66ea/hdl/axi_lite_ipif_v3_0_vh_rfs.vhd" \

vcom -work interrupt_control_v3_1_5 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/d8cc/hdl/interrupt_control_v3_1_vh_rfs.vhd" \

vcom -work axi_gpio_v2_0_33 -64 -93  \
"../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/4208/hdl/axi_gpio_v2_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_sel_gpio_0/sim/active_noise_cancelling_sel_gpio_0.vhd" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_err_gpio_0/sim/active_noise_cancelling_err_gpio_0.vhd" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_ref_gpio_0/sim/active_noise_cancelling_ref_gpio_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/ec67/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/a317/hdl" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/f0b6/hdl/verilog" "+incdir+../../../../anc.gen/sources_1/bd/active_noise_cancelling/ipshared/c783/hdl/verilog" "+incdir+/home/aiden/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/active_noise_cancelling/ip/active_noise_cancelling_ANC_0/sim/active_noise_cancelling_ANC_0.v" \
"../../../bd/active_noise_cancelling/sim/active_noise_cancelling.v" \

vlog -work xil_defaultlib \
"glbl.v"

