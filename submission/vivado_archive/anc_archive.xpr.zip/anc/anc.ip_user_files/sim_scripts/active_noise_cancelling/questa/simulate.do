onbreak {quit -f}
onerror {quit -f}

vsim  -lib xil_defaultlib active_noise_cancelling_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {active_noise_cancelling.udo}

run 1000ns

quit -force
